import client from "./client";

export const authApi = {
  register: (data) => client.post("/auth/register", data),
  login: (data) => client.post("/auth/login", data),
  forgotPassword: (data) => client.post("/auth/forgot-password", data),
  resetPassword: (data) => client.post("/auth/reset-password", data),
  me: () => client.get("/auth/me"),
  updateProfile: (data) => client.put("/auth/me", data),
};

export const dashboardApi = {
  summary: () => client.get("/dashboard/summary"),
};

export const carsApi = {
  list: (params) => client.get("/cars", { params }),
  get: (id) => client.get(`/cars/${id}`),
  create: (data) => client.post("/cars", data),
  update: (id, data) => client.put(`/cars/${id}`, data),
  remove: (id) => client.delete(`/cars/${id}`),
  updateChecklist: (id, data) => client.put(`/cars/${id}/checklist`, data),
  uploadImage: (id, formData) =>
    client.post(`/cars/${id}/images`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    }),
  generateQr: (id) => client.post(`/cars/${id}/qrcode`),
  downloadPdf: (id) => client.get(`/cars/${id}/pdf`, { responseType: "blob" }),
};

export const documentsApi = {
  listForCar: (carId) => client.get(`/cars/${carId}/documents`),
  upload: (carId, formData) =>
    client.post(`/cars/${carId}/documents`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    }),
  update: (id, data) => client.put(`/documents/${id}`, data),
  remove: (id) => client.delete(`/documents/${id}`),
  pending: () => client.get("/documents/pending"),
};

export const driversApi = {
  list: (params) => client.get("/drivers", { params }),
  get: (id) => client.get(`/drivers/${id}`),
  create: (data) => client.post("/drivers", data),
  update: (id, data) => client.put(`/drivers/${id}`, data),
  remove: (id) => client.delete(`/drivers/${id}`),
  assign: (id, carId) => client.post(`/drivers/${id}/assign`, { car_id: carId }),
  unassign: (id) => client.post(`/drivers/${id}/unassign`),
};

export const serviceApi = {
  listForCar: (carId) => client.get(`/cars/${carId}/service-records`),
  create: (carId, formData) => client.post(`/cars/${carId}/service-records`, formData),
  update: (id, data) => client.put(`/service-records/${id}`, data),
  remove: (id) => client.delete(`/service-records/${id}`),
};

export const bookingsApi = {
  list: (params) => client.get("/bookings", { params }),
  get: (id) => client.get(`/bookings/${id}`),
  create: (data) => client.post("/bookings", data),
  updateStatus: (id, status) => client.put(`/bookings/${id}/status`, { status }),
  downloadInvoice: (id) => client.get(`/bookings/${id}/invoice`, { responseType: "blob" }),
};

export const searchApi = {
  search: (params) => client.get("/search", { params }),
};

export const reportsApi = {
  monthlyRevenue: (year) => client.get("/reports/monthly-revenue", { params: { year } }),
  yearlyRevenue: () => client.get("/reports/yearly-revenue"),
  carUtilization: () => client.get("/reports/car-utilization"),
  mostBookedVehicle: () => client.get("/reports/most-booked-vehicle"),
  serviceCost: () => client.get("/reports/service-cost"),
  export: (type, format) =>
    client.get(`/reports/export/${type}`, { params: { format }, responseType: "blob" }),
};

export const notificationsApi = {
  list: () => client.get("/notifications"),
};

export const settingsApi = {
  get: () => client.get("/settings"),
  update: (data) => client.put("/settings", data),
};
