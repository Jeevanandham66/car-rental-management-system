import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import toast from "react-hot-toast";
import { QrCode, Download } from "lucide-react";
import { carsApi, documentsApi, serviceApi } from "../api/endpoints";
import Badge from "../components/Badge";

const CHECKLIST_ITEMS = [
  ["engine_ok", "Engine"], ["brakes_ok", "Brakes"], ["tyres_ok", "Tyres"], ["battery_ok", "Battery"],
  ["lights_ok", "Lights"], ["horn_ok", "Horn"], ["ac_ok", "AC"], ["seat_covers_ok", "Seat Covers"],
  ["music_system_ok", "Music System"], ["gps_ok", "GPS"],
];
const IMAGE_TYPES = ["front", "rear", "left", "right", "interior", "dashboard", "engine", "tyres"];
const DOCUMENT_TYPES = [
  "rc_book", "insurance", "fitness_certificate", "pollution_certificate",
  "road_tax", "permit", "driving_permit", "invoice", "service_records",
];

export default function CarDetail() {
  const { id } = useParams();
  const [car, setCar] = useState(null);
  const [tab, setTab] = useState("overview");
  const [documents, setDocuments] = useState([]);
  const [serviceRecords, setServiceRecords] = useState([]);

  const loadCar = () => carsApi.get(id).then(({ data }) => setCar(data.car));
  const loadDocuments = () => documentsApi.listForCar(id).then(({ data }) => setDocuments(data.documents));
  const loadService = () => serviceApi.listForCar(id).then(({ data }) => setServiceRecords(data.service_records));

  useEffect(() => {
    loadCar();
    loadDocuments();
    loadService();
  }, [id]);

  if (!car) return <p className="text-gray-500 dark:text-gray-400">Loading...</p>;

  const toggleChecklistItem = async (key) => {
    const updated = { ...car.checklist, [key]: !car.checklist?.[key] };
    setCar({ ...car, checklist: updated });
    await carsApi.updateChecklist(id, updated);
  };

  const uploadImage = async (imageType, file) => {
    const formData = new FormData();
    formData.append("image_type", imageType);
    formData.append("file", file);
    try {
      await carsApi.uploadImage(id, formData);
      toast.success("Image uploaded");
      loadCar();
    } catch {
      toast.error("Upload failed");
    }
  };

  const uploadDocument = async (e) => {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    try {
      await documentsApi.upload(id, formData);
      toast.success("Document uploaded");
      form.reset();
      loadDocuments();
    } catch {
      toast.error("Upload failed");
    }
  };

  const addServiceRecord = async (e) => {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    try {
      await serviceApi.create(id, formData);
      toast.success("Service record added");
      form.reset();
      loadService();
    } catch {
      toast.error("Failed to add record");
    }
  };

  const generateQr = async () => {
    try {
      await carsApi.generateQr(id);
      toast.success("QR code generated");
    } catch {
      toast.error("Failed to generate QR");
    }
  };

  const downloadPdf = async () => {
    const res = await carsApi.downloadPdf(id);
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${car.vehicle_number}_details.pdf`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
            {car.brand} {car.model} — {car.vehicle_number}
          </h1>
          <div className="flex gap-2 mt-1">
            <Badge value={car.availability_status} />
            <Badge value={car.condition} />
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={generateQr} className="btn-secondary flex items-center gap-2">
            <QrCode size={16} /> QR Code
          </button>
          <button onClick={downloadPdf} className="btn-secondary flex items-center gap-2">
            <Download size={16} /> PDF
          </button>
        </div>
      </div>

      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        {["overview", "checklist", "images", "documents", "service"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium capitalize border-b-2 -mb-px ${
              tab === t
                ? "border-brand-600 text-brand-600"
                : "border-transparent text-gray-500 dark:text-gray-400"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="card p-5 grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
          {[
            ["Engine Number", car.engine_number], ["Chassis Number", car.chassis_number],
            ["Odometer", `${car.odometer_reading} km`], ["Mileage", car.mileage],
            ["Seating Capacity", car.seating_capacity], ["Daily Rent", `₹${car.daily_rent}`],
            ["Weekly Rent", `₹${car.weekly_rent ?? "-"}`], ["Monthly Rent", `₹${car.monthly_rent ?? "-"}`],
            ["Security Deposit", `₹${car.security_deposit ?? 0}`], ["Extra KM Charge", `₹${car.extra_km_charge ?? 0}`],
            ["Night Charge", `₹${car.night_charge ?? 0}`], ["Driver Charge/Day", `₹${car.driver_charge_per_day ?? 0}`],
            ["Driver Option", car.driver_option], ["Fuel Type", car.fuel_type], ["Transmission", car.transmission],
          ].map(([label, value]) => (
            <div key={label}>
              <p className="text-gray-400 text-xs">{label}</p>
              <p className="text-gray-800 dark:text-gray-100 font-medium">{value}</p>
            </div>
          ))}
        </div>
      )}

      {tab === "checklist" && (
        <div className="card p-5 grid grid-cols-2 md:grid-cols-3 gap-3">
          {CHECKLIST_ITEMS.map(([key, label]) => (
            <label key={key} className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
              <input
                type="checkbox"
                checked={!!car.checklist?.[key]}
                onChange={() => toggleChecklistItem(key)}
                className="w-4 h-4 accent-brand-600"
              />
              {label}
            </label>
          ))}
        </div>
      )}

      {tab === "images" && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {IMAGE_TYPES.map((type) => {
            const existing = car.images?.find((img) => img.image_type === type);
            return (
              <div key={type} className="card p-3 text-center">
                <p className="text-xs text-gray-500 mb-2 capitalize">{type}</p>
                {existing ? (
                  <img src={`/api/${existing.file_path}`} alt={type} className="w-full h-24 object-cover rounded-lg mb-2" />
                ) : (
                  <div className="w-full h-24 bg-gray-100 dark:bg-gray-700 rounded-lg mb-2 flex items-center justify-center text-xs text-gray-400">
                    No image
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  className="text-xs"
                  onChange={(e) => e.target.files[0] && uploadImage(type, e.target.files[0])}
                />
              </div>
            );
          })}
        </div>
      )}

      {tab === "documents" && (
        <div className="space-y-4">
          <form onSubmit={uploadDocument} className="card p-4 grid grid-cols-2 md:grid-cols-4 gap-3 items-end">
            <div>
              <label className="label">Document Type</label>
              <select name="document_type" className="input-field" required>
                {DOCUMENT_TYPES.map((t) => (
                  <option key={t} value={t}>{t.replace(/_/g, " ")}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Issue Date</label>
              <input type="date" name="issue_date" className="input-field" />
            </div>
            <div>
              <label className="label">Expiry Date</label>
              <input type="date" name="expiry_date" className="input-field" />
            </div>
            <div>
              <label className="label">File</label>
              <input type="file" name="file" required className="input-field" />
            </div>
            <button type="submit" className="btn-primary col-span-2 md:col-span-4">Upload Document</button>
          </form>

          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-900/40 text-xs uppercase text-gray-500">
                <tr>
                  <th className="text-left px-4 py-3">Type</th>
                  <th className="text-left px-4 py-3">Issue Date</th>
                  <th className="text-left px-4 py-3">Expiry Date</th>
                  <th className="text-left px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {documents.map((d) => (
                  <tr key={d.id}>
                    <td className="px-4 py-3 capitalize">{d.document_type.replace(/_/g, " ")}</td>
                    <td className="px-4 py-3">{d.issue_date || "-"}</td>
                    <td className="px-4 py-3">{d.expiry_date || "-"}</td>
                    <td className="px-4 py-3"><Badge value={d.status} /></td>
                  </tr>
                ))}
                {documents.length === 0 && (
                  <tr><td colSpan={4} className="text-center py-8 text-gray-400">No documents uploaded yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "service" && (
        <div className="space-y-4">
          <form onSubmit={addServiceRecord} className="card p-4 grid grid-cols-2 md:grid-cols-4 gap-3 items-end">
            <div>
              <label className="label">Service Date</label>
              <input type="date" name="service_date" required className="input-field" />
            </div>
            <div>
              <label className="label">Service Center</label>
              <input name="service_center" className="input-field" />
            </div>
            <div>
              <label className="label">Service Type</label>
              <input name="service_type" className="input-field" placeholder="routine / repair" />
            </div>
            <div>
              <label className="label">Cost (₹)</label>
              <input type="number" name="cost" className="input-field" />
            </div>
            <div>
              <label className="label">Odometer</label>
              <input type="number" name="odometer_reading" className="input-field" />
            </div>
            <div>
              <label className="label">Next Service Due</label>
              <input type="date" name="next_service_due_date" className="input-field" />
            </div>
            <div className="col-span-2">
              <label className="label">Bill Upload</label>
              <input type="file" name="file" className="input-field" />
            </div>
            <button type="submit" className="btn-primary col-span-2 md:col-span-4">Add Service Record</button>
          </form>

          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-900/40 text-xs uppercase text-gray-500">
                <tr>
                  <th className="text-left px-4 py-3">Date</th>
                  <th className="text-left px-4 py-3">Center</th>
                  <th className="text-left px-4 py-3">Type</th>
                  <th className="text-left px-4 py-3">Cost</th>
                  <th className="text-left px-4 py-3">Next Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {serviceRecords.map((r) => (
                  <tr key={r.id}>
                    <td className="px-4 py-3">{r.service_date}</td>
                    <td className="px-4 py-3">{r.service_center || "-"}</td>
                    <td className="px-4 py-3">{r.service_type || "-"}</td>
                    <td className="px-4 py-3">₹{r.cost}</td>
                    <td className="px-4 py-3">{r.next_service_due_date || "-"}</td>
                  </tr>
                ))}
                {serviceRecords.length === 0 && (
                  <tr><td colSpan={5} className="text-center py-8 text-gray-400">No service records yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
