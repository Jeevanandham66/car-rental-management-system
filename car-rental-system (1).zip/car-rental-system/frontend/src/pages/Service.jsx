import { useEffect, useState } from "react";
import { carsApi, serviceApi } from "../api/endpoints";
import { SelectField } from "./Cars";

export default function Service() {
  const [cars, setCars] = useState([]);
  const [carId, setCarId] = useState("");
  const [records, setRecords] = useState([]);

  useEffect(() => {
    carsApi.list({ per_page: 100 }).then(({ data }) => setCars(data.cars));
  }, []);

  useEffect(() => {
    if (carId) {
      serviceApi.listForCar(carId).then(({ data }) => setRecords(data.service_records));
    } else {
      setRecords([]);
    }
  }, [carId]);

  const selectedCar = cars.find((c) => String(c.id) === carId);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Service History</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Select a vehicle to view or add service records. Full add/edit tools are on the vehicle's page.
        </p>
      </div>

      <div className="card p-4 max-w-sm">
        <SelectField
          label="Select Vehicle"
          value={carId}
          onChange={setCarId}
          options={["", ...cars.map((c) => String(c.id))]}
        />
        {selectedCar && (
          <p className="text-xs text-gray-400 mt-1">
            {selectedCar.vehicle_number} — {selectedCar.brand} {selectedCar.model}
          </p>
        )}
      </div>

      {carId && (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-900/40 text-xs uppercase text-gray-500">
              <tr>
                <th className="text-left px-4 py-3">Date</th>
                <th className="text-left px-4 py-3">Service Center</th>
                <th className="text-left px-4 py-3">Type</th>
                <th className="text-left px-4 py-3">Cost</th>
                <th className="text-left px-4 py-3">Odometer</th>
                <th className="text-left px-4 py-3">Next Due</th>
                <th className="text-left px-4 py-3">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
              {records.map((r) => (
                <tr key={r.id}>
                  <td className="px-4 py-3">{r.service_date}</td>
                  <td className="px-4 py-3">{r.service_center || "-"}</td>
                  <td className="px-4 py-3">{r.service_type || "-"}</td>
                  <td className="px-4 py-3">₹{r.cost}</td>
                  <td className="px-4 py-3">{r.odometer_reading ?? "-"}</td>
                  <td className="px-4 py-3">{r.next_service_due_date || "-"}</td>
                  <td className="px-4 py-3 text-gray-500">{r.notes || "-"}</td>
                </tr>
              ))}
              {records.length === 0 && (
                <tr><td colSpan={7} className="text-center py-8 text-gray-400">No service records for this vehicle</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
