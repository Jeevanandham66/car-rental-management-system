import { useEffect, useState } from "react";
import { documentsApi, carsApi } from "../api/endpoints";
import Badge from "../components/Badge";

export default function Documents() {
  const [pending, setPending] = useState([]);
  const [carsById, setCarsById] = useState({});

  useEffect(() => {
    documentsApi.pending().then(({ data }) => setPending(data.documents));
    carsApi.list({ per_page: 100 }).then(({ data }) => {
      const map = {};
      data.cars.forEach((c) => (map[c.id] = c));
      setCarsById(map);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Documents</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Expired or expiring documents across your fleet. Upload or renew documents from each vehicle's page.
        </p>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 dark:bg-gray-900/40 text-xs uppercase text-gray-500">
            <tr>
              <th className="text-left px-4 py-3">Vehicle</th>
              <th className="text-left px-4 py-3">Document Type</th>
              <th className="text-left px-4 py-3">Expiry Date</th>
              <th className="text-left px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {pending.map((d) => (
              <tr key={d.id}>
                <td className="px-4 py-3">{carsById[d.car_id]?.vehicle_number || `#${d.car_id}`}</td>
                <td className="px-4 py-3 capitalize">{d.document_type.replace(/_/g, " ")}</td>
                <td className="px-4 py-3">{d.expiry_date || "-"}</td>
                <td className="px-4 py-3"><Badge value={d.status} /></td>
              </tr>
            ))}
            {pending.length === 0 && (
              <tr><td colSpan={4} className="text-center py-10 text-gray-400">All documents are up to date 🎉</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
