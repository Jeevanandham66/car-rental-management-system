import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { settingsApi, authApi } from "../api/endpoints";
import { useAuth } from "../context/AuthContext";

export default function Settings() {
  const { owner, setOwner } = useAuth();
  const [settings, setSettings] = useState({ gst_percentage: 18, notification_days: 15, default_daily_rent: "" });
  const [profile, setProfile] = useState({ full_name: "", company_name: "", phone: "" });

  useEffect(() => {
    settingsApi.get().then(({ data }) => setSettings(data.settings));
  }, []);

  useEffect(() => {
    if (owner) {
      setProfile({
        full_name: owner.full_name || "",
        company_name: owner.company_name || "",
        phone: owner.phone || "",
      });
    }
  }, [owner]);

  const saveSettings = async (e) => {
    e.preventDefault();
    try {
      const { data } = await settingsApi.update(settings);
      setSettings(data.settings);
      toast.success("Settings updated");
    } catch {
      toast.error("Failed to update settings");
    }
  };

  const saveProfile = async (e) => {
    e.preventDefault();
    try {
      const { data } = await authApi.updateProfile(profile);
      setOwner(data.owner);
      toast.success("Profile updated");
    } catch {
      toast.error("Failed to update profile");
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Settings</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Business defaults and account profile.</p>
      </div>

      <form onSubmit={saveSettings} className="card p-5 space-y-4">
        <h2 className="font-semibold text-gray-900 dark:text-gray-100">Rental Defaults</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">GST Percentage (%)</label>
            <input
              type="number"
              className="input-field"
              value={settings.gst_percentage ?? ""}
              onChange={(e) => setSettings({ ...settings, gst_percentage: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Notification Days Before Expiry</label>
            <input
              type="number"
              className="input-field"
              value={settings.notification_days ?? ""}
              onChange={(e) => setSettings({ ...settings, notification_days: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Default Daily Rent (₹)</label>
            <input
              type="number"
              className="input-field"
              value={settings.default_daily_rent ?? ""}
              onChange={(e) => setSettings({ ...settings, default_daily_rent: e.target.value })}
            />
          </div>
        </div>
        <button type="submit" className="btn-primary">Save Settings</button>
      </form>

      <form onSubmit={saveProfile} className="card p-5 space-y-4">
        <h2 className="font-semibold text-gray-900 dark:text-gray-100">Profile</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Full Name</label>
            <input
              className="input-field"
              value={profile.full_name}
              onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Company Name</label>
            <input
              className="input-field"
              value={profile.company_name}
              onChange={(e) => setProfile({ ...profile, company_name: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Phone</label>
            <input
              className="input-field"
              value={profile.phone}
              onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Email</label>
            <input className="input-field" value={owner?.email || ""} disabled />
          </div>
        </div>
        <button type="submit" className="btn-primary">Save Profile</button>
      </form>
    </div>
  );
}
