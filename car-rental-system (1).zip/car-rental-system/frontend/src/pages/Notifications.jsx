import { useEffect, useState } from "react";
import { AlertTriangle, Clock } from "lucide-react";
import { notificationsApi } from "../api/endpoints";

export default function Notifications() {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    notificationsApi.list().then(({ data }) => setNotifications(data.notifications));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Notifications</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Reminders for insurance, FC, license and permit expiry, and upcoming service.
        </p>
      </div>

      <div className="space-y-2">
        {notifications.map((n, i) => (
          <div key={i} className="card p-4 flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                n.is_overdue
                  ? "bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-400"
                  : "bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400"
              }`}
            >
              {n.is_overdue ? <AlertTriangle size={18} /> : <Clock size={18} />}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-800 dark:text-gray-100">{n.title}</p>
              <p className="text-xs text-gray-400 capitalize">{n.type.replace(/_/g, " ")}</p>
            </div>
            <span className={`text-xs font-medium ${n.is_overdue ? "text-red-600" : "text-amber-600"}`}>
              {n.due_date}
            </span>
          </div>
        ))}
        {notifications.length === 0 && (
          <div className="card p-10 text-center text-gray-400">You're all caught up 🎉</div>
        )}
      </div>
    </div>
  );
}
