import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import toast from "react-hot-toast";
import { carsApi } from "../api/endpoints";
import DataTable from "../components/DataTable";
import Badge from "../components/Badge";
import Modal from "../components/Modal";

const emptyCar = {
  vehicle_number: "", brand: "", model: "", variant: "", manufacturing_year: new Date().getFullYear(),
  fuel_type: "Petrol", transmission: "Manual", color: "", seating_capacity: 4,
  daily_rent: "", weekly_rent: "", monthly_rent: "", security_deposit: "",
  extra_km_charge: "", night_charge: "", driver_charge_per_day: "",
  driver_option: "both", availability_status: "available", condition: "good",
};

export default function Cars() {
  const [cars, setCars] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyCar);
  const [saving, setSaving] = useState(false);

  const load = () => {
    carsApi.list({ page, search }).then(({ data }) => {
      setCars(data.cars);
      setPages(data.pages);
    });
  };

  useEffect(load, [page, search]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await carsApi.create(form);
      toast.success("Car added");
      setShowModal(false);
      setForm(emptyCar);
      load();
    } catch (err) {
      const errs = err.response?.data?.errors;
      toast.error(errs ? Object.values(errs)[0] : "Failed to add car");
    } finally {
      setSaving(false);
    }
  };

  const columns = [
    { key: "vehicle_number", header: "Vehicle #" },
    { key: "brand", header: "Brand / Model", render: (r) => `${r.brand} ${r.model}` },
    { key: "fuel_type", header: "Fuel" },
    { key: "daily_rent", header: "Daily Rent", render: (r) => `₹${r.daily_rent}` },
    { key: "availability_status", header: "Status", render: (r) => <Badge value={r.availability_status} /> },
    { key: "condition", header: "Condition", render: (r) => <Badge value={r.condition} /> },
    {
      key: "actions",
      header: "",
      render: (r) => (
        <Link to={`/cars/${r.id}`} className="text-brand-600 hover:underline text-sm">
          View
        </Link>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Cars</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Manage your rental fleet.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Car
        </button>
      </div>

      <DataTable
        columns={columns}
        rows={cars}
        onSearch={setSearch}
        searchValue={search}
        page={page}
        pages={pages}
        onPageChange={setPage}
        emptyMessage="No cars yet. Add your first vehicle."
      />

      {showModal && (
        <Modal title="Add New Car" onClose={() => setShowModal(false)} wide>
          <form onSubmit={handleCreate} className="grid grid-cols-2 gap-4">
            <Field label="Vehicle Number" value={form.vehicle_number} onChange={(v) => setForm({ ...form, vehicle_number: v })} required />
            <Field label="Brand" value={form.brand} onChange={(v) => setForm({ ...form, brand: v })} required />
            <Field label="Model" value={form.model} onChange={(v) => setForm({ ...form, model: v })} required />
            <Field label="Variant" value={form.variant} onChange={(v) => setForm({ ...form, variant: v })} />
            <Field label="Manufacturing Year" type="number" value={form.manufacturing_year} onChange={(v) => setForm({ ...form, manufacturing_year: v })} required />
            <SelectField label="Fuel Type" value={form.fuel_type} onChange={(v) => setForm({ ...form, fuel_type: v })} options={["Petrol", "Diesel", "CNG", "Electric", "Hybrid"]} />
            <SelectField label="Transmission" value={form.transmission} onChange={(v) => setForm({ ...form, transmission: v })} options={["Manual", "Automatic"]} />
            <Field label="Color" value={form.color} onChange={(v) => setForm({ ...form, color: v })} />
            <Field label="Seating Capacity" type="number" value={form.seating_capacity} onChange={(v) => setForm({ ...form, seating_capacity: v })} />
            <Field label="Daily Rent (₹)" type="number" value={form.daily_rent} onChange={(v) => setForm({ ...form, daily_rent: v })} required />
            <Field label="Weekly Rent (₹)" type="number" value={form.weekly_rent} onChange={(v) => setForm({ ...form, weekly_rent: v })} />
            <Field label="Monthly Rent (₹)" type="number" value={form.monthly_rent} onChange={(v) => setForm({ ...form, monthly_rent: v })} />
            <Field label="Security Deposit (₹)" type="number" value={form.security_deposit} onChange={(v) => setForm({ ...form, security_deposit: v })} />
            <Field label="Extra KM Charge (₹)" type="number" value={form.extra_km_charge} onChange={(v) => setForm({ ...form, extra_km_charge: v })} />
            <Field label="Night Charge (₹)" type="number" value={form.night_charge} onChange={(v) => setForm({ ...form, night_charge: v })} />
            <Field label="Driver Charge/Day (₹)" type="number" value={form.driver_charge_per_day} onChange={(v) => setForm({ ...form, driver_charge_per_day: v })} />
            <SelectField label="Driver Option" value={form.driver_option} onChange={(v) => setForm({ ...form, driver_option: v })} options={["with_driver", "without_driver", "both"]} />
            <SelectField label="Availability" value={form.availability_status} onChange={(v) => setForm({ ...form, availability_status: v })} options={["available", "booked", "service", "inactive"]} />
            <SelectField label="Condition" value={form.condition} onChange={(v) => setForm({ ...form, condition: v })} options={["excellent", "very_good", "good", "needs_service"]} />

            <div className="col-span-2 flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">
                Cancel
              </button>
              <button type="submit" disabled={saving} className="btn-primary">
                {saving ? "Saving..." : "Save Car"}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, value, onChange, type = "text", required }) {
  return (
    <div>
      <label className="label">{label}</label>
      <input
        type={type}
        required={required}
        className="input-field"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

function SelectField({ label, value, onChange, options }) {
  return (
    <div>
      <label className="label">{label}</label>
      <select className="input-field" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => (
          <option key={o} value={o}>
            {o.replace(/_/g, " ")}
          </option>
        ))}
      </select>
    </div>
  );
}

export { Field, SelectField };
