import { useEffect, useState } from "react";
import { Plus, UserCheck, UserX } from "lucide-react";
import toast from "react-hot-toast";
import { driversApi, carsApi } from "../api/endpoints";
import DataTable from "../components/DataTable";
import Badge from "../components/Badge";
import Modal from "../components/Modal";
import { Field, SelectField } from "./Cars";

const emptyDriver = {
  name: "", phone: "", license_number: "", license_expiry: "",
  address: "", aadhar_number: "", experience_years: "", salary: "", status: "active",
};

export default function Drivers() {
  const [drivers, setDrivers] = useState([]);
  const [cars, setCars] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [assignTarget, setAssignTarget] = useState(null);
  const [selectedCarId, setSelectedCarId] = useState("");
  const [form, setForm] = useState(emptyDriver);
  const [saving, setSaving] = useState(false);

  const load = () => {
    driversApi.list({ page, search }).then(({ data }) => {
      setDrivers(data.drivers);
      setPages(data.pages);
    });
  };

  useEffect(load, [page, search]);
  useEffect(() => {
    carsApi.list({ per_page: 100 }).then(({ data }) => setCars(data.cars));
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await driversApi.create(form);
      toast.success("Driver added");
      setShowModal(false);
      setForm(emptyDriver);
      load();
    } catch (err) {
      const errs = err.response?.data?.errors;
      toast.error(errs ? Object.values(errs)[0] : "Failed to add driver");
    } finally {
      setSaving(false);
    }
  };

  const handleAssign = async () => {
    if (!selectedCarId) return;
    try {
      await driversApi.assign(assignTarget.id, selectedCarId);
      toast.success(`${assignTarget.name} assigned`);
      setAssignTarget(null);
      setSelectedCarId("");
      load();
    } catch {
      toast.error("Assignment failed");
    }
  };

  const handleUnassign = async (driver) => {
    try {
      await driversApi.unassign(driver.id);
      toast.success(`${driver.name} unassigned`);
      load();
    } catch {
      toast.error("Failed to unassign");
    }
  };

  const columns = [
    { key: "name", header: "Name" },
    { key: "phone", header: "Phone" },
    { key: "license_number", header: "License #" },
    { key: "license_expiry", header: "License Expiry" },
    { key: "status", header: "Status", render: (r) => <Badge value={r.status} /> },
    {
      key: "actions",
      header: "",
      render: (r) =>
        r.status === "on_trip" ? (
          <button onClick={() => handleUnassign(r)} className="text-red-600 hover:underline text-sm flex items-center gap-1">
            <UserX size={14} /> Unassign
          </button>
        ) : (
          <button onClick={() => setAssignTarget(r)} className="text-brand-600 hover:underline text-sm flex items-center gap-1">
            <UserCheck size={14} /> Assign
          </button>
        ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Drivers</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Manage your drivers and vehicle assignments.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> Add Driver
        </button>
      </div>

      <DataTable
        columns={columns}
        rows={drivers}
        onSearch={setSearch}
        searchValue={search}
        page={page}
        pages={pages}
        onPageChange={setPage}
        emptyMessage="No drivers yet."
      />

      {showModal && (
        <Modal title="Add New Driver" onClose={() => setShowModal(false)} wide>
          <form onSubmit={handleCreate} className="grid grid-cols-2 gap-4">
            <Field label="Full Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
            <Field label="Phone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} required />
            <Field label="License Number" value={form.license_number} onChange={(v) => setForm({ ...form, license_number: v })} required />
            <Field label="License Expiry" type="date" value={form.license_expiry} onChange={(v) => setForm({ ...form, license_expiry: v })} required />
            <Field label="Aadhar Number" value={form.aadhar_number} onChange={(v) => setForm({ ...form, aadhar_number: v })} />
            <Field label="Experience (years)" type="number" value={form.experience_years} onChange={(v) => setForm({ ...form, experience_years: v })} />
            <Field label="Salary (₹)" type="number" value={form.salary} onChange={(v) => setForm({ ...form, salary: v })} />
            <SelectField label="Status" value={form.status} onChange={(v) => setForm({ ...form, status: v })} options={["active", "inactive"]} />
            <div className="col-span-2">
              <label className="label">Address</label>
              <textarea className="input-field" rows={2} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            </div>
            <div className="col-span-2 flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary">{saving ? "Saving..." : "Save Driver"}</button>
            </div>
          </form>
        </Modal>
      )}

      {assignTarget && (
        <Modal title={`Assign a vehicle to ${assignTarget.name}`} onClose={() => setAssignTarget(null)}>
          <SelectField
            label="Select Car"
            value={selectedCarId}
            onChange={setSelectedCarId}
            options={["", ...cars.map((c) => String(c.id))]}
          />
          <p className="text-xs text-gray-400 mt-1 mb-3">
            {cars.find((c) => String(c.id) === selectedCarId)
              ? `${cars.find((c) => String(c.id) === selectedCarId).vehicle_number} - ${cars.find((c) => String(c.id) === selectedCarId).brand}`
              : "Choose a vehicle"}
          </p>
          <div className="flex justify-end gap-3">
            <button onClick={() => setAssignTarget(null)} className="btn-secondary">Cancel</button>
            <button onClick={handleAssign} className="btn-primary">Assign</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
