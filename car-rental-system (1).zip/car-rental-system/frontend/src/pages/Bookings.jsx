import { useEffect, useState } from "react";
import { Plus, Download } from "lucide-react";
import toast from "react-hot-toast";
import { bookingsApi, carsApi, driversApi } from "../api/endpoints";
import DataTable from "../components/DataTable";
import Badge from "../components/Badge";
import Modal from "../components/Modal";
import { Field, SelectField } from "./Cars";

const emptyBooking = {
  car_id: "", driver_id: "", customer_name: "", customer_phone: "", customer_email: "",
  pickup_date: "", return_date: "", pickup_location: "", drop_location: "",
  rental_type: "without_driver", extra_km_used: 0, discount: 0, security_deposit_collected: 0,
};

export default function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [cars, setCars] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyBooking);
  const [saving, setSaving] = useState(false);

  const load = () => {
    bookingsApi.list({ page, search }).then(({ data }) => {
      setBookings(data.bookings);
      setPages(data.pages);
    });
  };

  useEffect(load, [page, search]);
  useEffect(() => {
    carsApi.list({ per_page: 100, availability_status: "available" }).then(({ data }) => setCars(data.cars));
    driversApi.list({ per_page: 100, status: "active" }).then(({ data }) => setDrivers(data.drivers));
  }, [showModal]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form };
      if (!payload.driver_id) delete payload.driver_id;
      await bookingsApi.create(payload);
      toast.success("Booking created and invoice calculated");
      setShowModal(false);
      setForm(emptyBooking);
      load();
    } catch (err) {
      const errs = err.response?.data?.errors;
      toast.error(errs ? Object.values(errs)[0] : "Failed to create booking");
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (booking, status) => {
    try {
      await bookingsApi.updateStatus(booking.id, status);
      toast.success(`Booking marked as ${status}`);
      load();
    } catch {
      toast.error("Failed to update status");
    }
  };

  const downloadInvoice = async (booking) => {
    const res = await bookingsApi.downloadInvoice(booking.id);
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement("a");
    a.href = url;
    a.download = `invoice_${booking.booking_number}.pdf`;
    a.click();
  };

  const columns = [
    { key: "booking_number", header: "Booking #" },
    { key: "customer_name", header: "Customer" },
    { key: "rental_type", header: "Type", render: (r) => r.rental_type.replace(/_/g, " ") },
    { key: "number_of_days", header: "Days" },
    { key: "total_amount", header: "Total", render: (r) => `₹${r.total_amount}` },
    { key: "status", header: "Status", render: (r) => <Badge value={r.status} /> },
    {
      key: "actions",
      header: "",
      render: (r) => (
        <div className="flex items-center gap-3">
          <button onClick={() => downloadInvoice(r)} className="text-brand-600 hover:underline text-sm flex items-center gap-1">
            <Download size={14} /> Invoice
          </button>
          {r.status === "confirmed" && (
            <button onClick={() => updateStatus(r, "ongoing")} className="text-amber-600 hover:underline text-sm">Start</button>
          )}
          {r.status === "ongoing" && (
            <button onClick={() => updateStatus(r, "completed")} className="text-green-600 hover:underline text-sm">Complete</button>
          )}
          {["confirmed", "ongoing"].includes(r.status) && (
            <button onClick={() => updateStatus(r, "cancelled")} className="text-red-600 hover:underline text-sm">Cancel</button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Bookings</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Create and track customer bookings.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> New Booking
        </button>
      </div>

      <DataTable
        columns={columns}
        rows={bookings}
        onSearch={setSearch}
        searchValue={search}
        page={page}
        pages={pages}
        onPageChange={setPage}
        emptyMessage="No bookings yet."
      />

      {showModal && (
        <Modal title="New Booking" onClose={() => setShowModal(false)} wide>
          <form onSubmit={handleCreate} className="grid grid-cols-2 gap-4">
            <SelectField
              label="Car"
              value={form.car_id}
              onChange={(v) => setForm({ ...form, car_id: v })}
              options={["", ...cars.map((c) => String(c.id))]}
            />
            <SelectField
              label="Rental Type"
              value={form.rental_type}
              onChange={(v) => setForm({ ...form, rental_type: v })}
              options={["without_driver", "with_driver"]}
            />
            {form.rental_type === "with_driver" && (
              <SelectField
                label="Driver"
                value={form.driver_id}
                onChange={(v) => setForm({ ...form, driver_id: v })}
                options={["", ...drivers.map((d) => String(d.id))]}
              />
            )}
            <Field label="Customer Name" value={form.customer_name} onChange={(v) => setForm({ ...form, customer_name: v })} required />
            <Field label="Customer Phone" value={form.customer_phone} onChange={(v) => setForm({ ...form, customer_phone: v })} required />
            <Field label="Customer Email" type="email" value={form.customer_email} onChange={(v) => setForm({ ...form, customer_email: v })} />
            <Field label="Pickup Date/Time" type="datetime-local" value={form.pickup_date} onChange={(v) => setForm({ ...form, pickup_date: v })} required />
            <Field label="Return Date/Time" type="datetime-local" value={form.return_date} onChange={(v) => setForm({ ...form, return_date: v })} required />
            <Field label="Pickup Location" value={form.pickup_location} onChange={(v) => setForm({ ...form, pickup_location: v })} />
            <Field label="Drop Location" value={form.drop_location} onChange={(v) => setForm({ ...form, drop_location: v })} />
            <Field label="Extra KM Used" type="number" value={form.extra_km_used} onChange={(v) => setForm({ ...form, extra_km_used: v })} />
            <Field label="Discount (₹)" type="number" value={form.discount} onChange={(v) => setForm({ ...form, discount: v })} />
            <Field label="Security Deposit Collected (₹)" type="number" value={form.security_deposit_collected} onChange={(v) => setForm({ ...form, security_deposit_collected: v })} />

            <p className="col-span-2 text-xs text-gray-400">
              Rent, driver charge, GST and total are calculated automatically on save.
            </p>

            <div className="col-span-2 flex justify-end gap-3 pt-2">
              <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary">{saving ? "Saving..." : "Create Booking"}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
