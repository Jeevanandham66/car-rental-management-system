import { useEffect, useState } from "react";
import { Car, CheckCircle, Clock, Wrench, IndianRupee, CalendarClock, FileWarning, ShieldAlert } from "lucide-react";
import { dashboardApi } from "../api/endpoints";
import StatCard from "../components/StatCard";

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardApi
      .summary()
      .then(({ data }) => setSummary(data.summary))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-gray-500 dark:text-gray-400">Loading dashboard...</p>;
  if (!summary) return <p className="text-gray-500 dark:text-gray-400">Could not load dashboard data.</p>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Overview of your fleet and business.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Cars" value={summary.total_cars} icon={Car} accent="brand" />
        <StatCard label="Available" value={summary.cars_available} icon={CheckCircle} accent="green" />
        <StatCard label="Booked" value={summary.cars_booked} icon={CalendarClock} accent="amber" />
        <StatCard label="Under Service" value={summary.cars_under_service} icon={Wrench} accent="red" />
        <StatCard
          label="Monthly Revenue"
          value={`₹${summary.monthly_revenue.toLocaleString()}`}
          icon={IndianRupee}
          accent="green"
        />
        <StatCard label="Today's Bookings" value={summary.todays_bookings} icon={Clock} accent="brand" />
        <StatCard label="Pending Documents" value={summary.pending_documents} icon={FileWarning} accent="amber" />
        <StatCard
          label="Expiring Insurance/FC"
          value={summary.upcoming_insurance_expiry.length + summary.upcoming_fc_expiry.length}
          icon={ShieldAlert}
          accent="red"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card p-4">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">Upcoming Insurance Expiry</h2>
          {summary.upcoming_insurance_expiry.length === 0 ? (
            <p className="text-sm text-gray-400">Nothing due in the next 30 days.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {summary.upcoming_insurance_expiry.map((d) => (
                <li key={d.id} className="flex justify-between text-gray-600 dark:text-gray-300">
                  <span>Vehicle #{d.car_id}</span>
                  <span className="text-amber-600 dark:text-amber-400">{d.expiry_date}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="card p-4">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">Upcoming FC Expiry</h2>
          {summary.upcoming_fc_expiry.length === 0 ? (
            <p className="text-sm text-gray-400">Nothing due in the next 30 days.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {summary.upcoming_fc_expiry.map((d) => (
                <li key={d.id} className="flex justify-between text-gray-600 dark:text-gray-300">
                  <span>Vehicle #{d.car_id}</span>
                  <span className="text-amber-600 dark:text-amber-400">{d.expiry_date}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
