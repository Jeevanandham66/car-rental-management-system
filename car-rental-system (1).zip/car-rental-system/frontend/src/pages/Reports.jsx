import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Download } from "lucide-react";
import { reportsApi } from "../api/endpoints";

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function Reports() {
  const [monthlyRevenue, setMonthlyRevenue] = useState([]);
  const [utilization, setUtilization] = useState([]);
  const [mostBooked, setMostBooked] = useState(null);
  const [serviceCost, setServiceCost] = useState([]);

  useEffect(() => {
    reportsApi.monthlyRevenue(new Date().getFullYear()).then(({ data }) =>
      setMonthlyRevenue(
        data.monthly_revenue.map((r) => ({ month: MONTH_NAMES[r.month - 1], revenue: r.revenue }))
      )
    );
    reportsApi.carUtilization().then(({ data }) => setUtilization(data.car_utilization));
    reportsApi.mostBookedVehicle().then(({ data }) => setMostBooked(data.most_booked_vehicle));
    reportsApi.serviceCost().then(({ data }) => setServiceCost(data.service_cost_report));
  }, []);

  const exportReport = async (type, format) => {
    const res = await reportsApi.export(type, format);
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${type}.${format === "excel" ? "xlsx" : "pdf"}`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-gray-900 dark:text-gray-100">Reports</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">Revenue, utilization and service insights.</p>
      </div>

      <div className="card p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100">Monthly Revenue ({new Date().getFullYear()})</h2>
          <div className="flex gap-2">
            <ExportButton onClick={() => exportReport("monthly-revenue", "pdf")} label="PDF" />
            <ExportButton onClick={() => exportReport("monthly-revenue", "excel")} label="Excel" />
          </div>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={monthlyRevenue}>
            <XAxis dataKey="month" stroke="#9ca3af" fontSize={12} />
            <YAxis stroke="#9ca3af" fontSize={12} />
            <Tooltip />
            <Bar dataKey="revenue" fill="#2563eb" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {mostBooked && (
        <div className="card p-4">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Most Booked Vehicle</h2>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            {mostBooked.brand} {mostBooked.model} ({mostBooked.vehicle_number}) — {mostBooked.total_bookings} bookings
          </p>
        </div>
      )}

      <div className="card p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100">Car Utilization</h2>
          <div className="flex gap-2">
            <ExportButton onClick={() => exportReport("car-utilization", "pdf")} label="PDF" />
            <ExportButton onClick={() => exportReport("car-utilization", "excel")} label="Excel" />
          </div>
        </div>
        <ReportTable
          rows={utilization}
          columns={[
            ["vehicle_number", "Vehicle"], ["brand", "Brand"], ["model", "Model"],
            ["total_bookings", "Bookings"], ["total_days_booked", "Days Booked"],
          ]}
        />
      </div>

      <div className="card p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100">Service Cost Report</h2>
          <div className="flex gap-2">
            <ExportButton onClick={() => exportReport("service-cost", "pdf")} label="PDF" />
            <ExportButton onClick={() => exportReport("service-cost", "excel")} label="Excel" />
          </div>
        </div>
        <ReportTable
          rows={serviceCost}
          columns={[
            ["vehicle_number", "Vehicle"], ["brand", "Brand"], ["model", "Model"],
            ["service_count", "Services"], ["total_service_cost", "Total Cost (₹)"],
          ]}
        />
      </div>
    </div>
  );
}

function ExportButton({ onClick, label }) {
  return (
    <button onClick={onClick} className="btn-secondary text-xs flex items-center gap-1 px-2 py-1">
      <Download size={12} /> {label}
    </button>
  );
}

function ReportTable({ rows, columns }) {
  return (
    <table className="w-full text-sm">
      <thead className="bg-gray-50 dark:bg-gray-900/40 text-xs uppercase text-gray-500">
        <tr>{columns.map(([key, label]) => <th key={key} className="text-left px-3 py-2">{label}</th>)}</tr>
      </thead>
      <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
        {rows.map((r, i) => (
          <tr key={r.car_id || i}>
            {columns.map(([key]) => <td key={key} className="px-3 py-2">{r[key]}</td>)}
          </tr>
        ))}
        {rows.length === 0 && (
          <tr><td colSpan={columns.length} className="text-center py-6 text-gray-400">No data yet</td></tr>
        )}
      </tbody>
    </table>
  );
}
