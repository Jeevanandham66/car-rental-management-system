-- =====================================================================
-- Car Rental Management System - PostgreSQL Schema
-- =====================================================================

CREATE DATABASE car_rental_db;
-- Connect to car_rental_db before running the rest of this script.

-- ---------------------------------------------------------------------
-- Owners (rental car business owners / users of the system)
-- ---------------------------------------------------------------------
CREATE TABLE owners (
    id                  SERIAL PRIMARY KEY,
    full_name           VARCHAR(120) NOT NULL,
    email               VARCHAR(150) UNIQUE NOT NULL,
    phone               VARCHAR(20) UNIQUE NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    company_name        VARCHAR(150),
    profile_photo       VARCHAR(255),
    reset_token         VARCHAR(255),
    reset_token_expiry  TIMESTAMP,
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE owner_settings (
    id                  SERIAL PRIMARY KEY,
    owner_id            INTEGER UNIQUE NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
    gst_percentage      NUMERIC(5,2) DEFAULT 18.00,
    notification_days   INTEGER DEFAULT 15,
    default_daily_rent  NUMERIC(10,2),
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- Cars
-- ---------------------------------------------------------------------
CREATE TABLE cars (
    id                      SERIAL PRIMARY KEY,
    owner_id                INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,

    vehicle_number          VARCHAR(20) UNIQUE NOT NULL,
    brand                   VARCHAR(80) NOT NULL,
    model                   VARCHAR(80) NOT NULL,
    variant                 VARCHAR(80),
    manufacturing_year      INTEGER NOT NULL,
    fuel_type               VARCHAR(20) NOT NULL CHECK (fuel_type IN ('Petrol','Diesel','CNG','Electric','Hybrid')),
    transmission            VARCHAR(20) NOT NULL CHECK (transmission IN ('Manual','Automatic')),
    color                   VARCHAR(40),
    engine_number           VARCHAR(80) UNIQUE,
    chassis_number          VARCHAR(80) UNIQUE,
    odometer_reading        INTEGER DEFAULT 0,
    mileage                 NUMERIC(6,2),
    seating_capacity        INTEGER DEFAULT 4,

    daily_rent              NUMERIC(10,2) NOT NULL,
    weekly_rent             NUMERIC(10,2),
    monthly_rent            NUMERIC(10,2),
    security_deposit        NUMERIC(10,2) DEFAULT 0,
    extra_km_charge         NUMERIC(10,2) DEFAULT 0,
    night_charge            NUMERIC(10,2) DEFAULT 0,
    driver_charge_per_day   NUMERIC(10,2) DEFAULT 0,

    driver_option           VARCHAR(20) DEFAULT 'both' CHECK (driver_option IN ('with_driver','without_driver','both')),
    availability_status     VARCHAR(20) DEFAULT 'available' CHECK (availability_status IN ('available','booked','service','inactive')),
    condition               VARCHAR(20) DEFAULT 'good' CHECK (condition IN ('excellent','very_good','good','needs_service')),

    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cars_owner_id ON cars(owner_id);
CREATE INDEX idx_cars_availability ON cars(availability_status);
CREATE INDEX idx_cars_vehicle_number ON cars(vehicle_number);

CREATE TABLE car_inspection_checklist (
    id                  SERIAL PRIMARY KEY,
    car_id              INTEGER UNIQUE NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
    engine_ok           BOOLEAN DEFAULT FALSE,
    brakes_ok           BOOLEAN DEFAULT FALSE,
    tyres_ok            BOOLEAN DEFAULT FALSE,
    battery_ok          BOOLEAN DEFAULT FALSE,
    lights_ok           BOOLEAN DEFAULT FALSE,
    horn_ok             BOOLEAN DEFAULT FALSE,
    ac_ok               BOOLEAN DEFAULT FALSE,
    seat_covers_ok      BOOLEAN DEFAULT FALSE,
    music_system_ok     BOOLEAN DEFAULT FALSE,
    gps_ok              BOOLEAN DEFAULT FALSE,
    checked_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE car_images (
    id                  SERIAL PRIMARY KEY,
    car_id              INTEGER NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
    image_type          VARCHAR(20) NOT NULL CHECK (image_type IN
                            ('front','rear','left','right','interior','dashboard','engine','tyres')),
    file_path           VARCHAR(255) NOT NULL,
    uploaded_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (car_id, image_type)
);

-- ---------------------------------------------------------------------
-- Vehicle Documents
-- ---------------------------------------------------------------------
CREATE TABLE vehicle_documents (
    id                      SERIAL PRIMARY KEY,
    car_id                  INTEGER NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
    document_type           VARCHAR(40) NOT NULL CHECK (document_type IN
                                ('rc_book','insurance','fitness_certificate','pollution_certificate',
                                 'road_tax','permit','driving_permit','invoice','service_records')),
    file_path               VARCHAR(255) NOT NULL,
    issue_date              DATE,
    expiry_date              DATE,
    reminder_days_before     INTEGER DEFAULT 15,
    status                   VARCHAR(20) DEFAULT 'valid' CHECK (status IN ('valid','expiring_soon','expired')),
    created_at               TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at               TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_documents_car_id ON vehicle_documents(car_id);
CREATE INDEX idx_documents_expiry ON vehicle_documents(expiry_date);

-- ---------------------------------------------------------------------
-- Drivers
-- ---------------------------------------------------------------------
CREATE TABLE drivers (
    id                  SERIAL PRIMARY KEY,
    owner_id            INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
    name                VARCHAR(120) NOT NULL,
    photo               VARCHAR(255),
    phone               VARCHAR(20) NOT NULL,
    license_number      VARCHAR(60) UNIQUE NOT NULL,
    license_expiry      DATE NOT NULL,
    address             TEXT,
    aadhar_number       VARCHAR(20),
    experience_years    NUMERIC(4,1),
    salary              NUMERIC(10,2),
    status              VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive','on_trip')),
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_drivers_owner_id ON drivers(owner_id);
CREATE INDEX idx_drivers_license_expiry ON drivers(license_expiry);

CREATE TABLE driver_assignments (
    id                  SERIAL PRIMARY KEY,
    driver_id           INTEGER NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    car_id              INTEGER NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
    assigned_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    unassigned_at       TIMESTAMP,
    is_active           BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_driver_assignments_driver ON driver_assignments(driver_id);
CREATE INDEX idx_driver_assignments_car ON driver_assignments(car_id);

-- ---------------------------------------------------------------------
-- Service History
-- ---------------------------------------------------------------------
CREATE TABLE service_records (
    id                      SERIAL PRIMARY KEY,
    car_id                  INTEGER NOT NULL REFERENCES cars(id) ON DELETE CASCADE,
    service_date            DATE NOT NULL,
    service_center          VARCHAR(150),
    service_type            VARCHAR(80),
    cost                     NUMERIC(10,2) DEFAULT 0,
    odometer_reading         INTEGER,
    next_service_due_date    DATE,
    next_service_due_km      INTEGER,
    bill_upload              VARCHAR(255),
    notes                    TEXT,
    created_at                TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_service_records_car_id ON service_records(car_id);
CREATE INDEX idx_service_next_due ON service_records(next_service_due_date);

-- ---------------------------------------------------------------------
-- Bookings
-- ---------------------------------------------------------------------
CREATE TABLE bookings (
    id                              SERIAL PRIMARY KEY,
    owner_id                        INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
    car_id                          INTEGER NOT NULL REFERENCES cars(id),
    driver_id                       INTEGER REFERENCES drivers(id),

    booking_number                  VARCHAR(30) UNIQUE NOT NULL,

    customer_name                   VARCHAR(120) NOT NULL,
    customer_phone                  VARCHAR(20) NOT NULL,
    customer_email                  VARCHAR(150),
    driving_license_upload          VARCHAR(255),

    pickup_date                     TIMESTAMP NOT NULL,
    return_date                     TIMESTAMP NOT NULL,
    pickup_location                 VARCHAR(200),
    drop_location                   VARCHAR(200),

    rental_type                     VARCHAR(20) NOT NULL CHECK (rental_type IN ('with_driver','without_driver')),

    number_of_days                  INTEGER NOT NULL,
    rent_amount                     NUMERIC(10,2) NOT NULL,
    driver_charge                   NUMERIC(10,2) DEFAULT 0,
    extra_km_used                   INTEGER DEFAULT 0,
    extra_km_charge_total           NUMERIC(10,2) DEFAULT 0,
    subtotal                        NUMERIC(10,2) NOT NULL,
    gst_percentage                  NUMERIC(5,2) DEFAULT 18,
    gst_amount                      NUMERIC(10,2) DEFAULT 0,
    discount                        NUMERIC(10,2) DEFAULT 0,
    total_amount                    NUMERIC(10,2) NOT NULL,
    security_deposit_collected      NUMERIC(10,2) DEFAULT 0,

    status                          VARCHAR(20) DEFAULT 'confirmed' CHECK (status IN ('confirmed','ongoing','completed','cancelled')),

    invoice_number                  VARCHAR(30),
    invoice_pdf_path                VARCHAR(255),

    created_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CHECK (return_date > pickup_date)
);

CREATE INDEX idx_bookings_owner_id ON bookings(owner_id);
CREATE INDEX idx_bookings_car_id ON bookings(car_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_pickup_date ON bookings(pickup_date);

-- ---------------------------------------------------------------------
-- Notifications (persisted log; live reminders are also computed on the fly)
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    id                  SERIAL PRIMARY KEY,
    owner_id            INTEGER NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
    notification_type   VARCHAR(40) NOT NULL CHECK (notification_type IN
                            ('insurance_expiry','fc_expiry','license_expiry','permit_expiry',
                             'service_due','document_expiry')),
    reference_table     VARCHAR(40),
    reference_id        INTEGER,
    title               VARCHAR(200) NOT NULL,
    message             TEXT,
    due_date            DATE,
    is_read             BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_owner_id ON notifications(owner_id);
CREATE INDEX idx_notifications_due_date ON notifications(due_date);

-- ---------------------------------------------------------------------
-- Trigger: keep updated_at fresh
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_owners_updated_at BEFORE UPDATE ON owners
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_cars_updated_at BEFORE UPDATE ON cars
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_documents_updated_at BEFORE UPDATE ON vehicle_documents
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_drivers_updated_at BEFORE UPDATE ON drivers
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_bookings_updated_at BEFORE UPDATE ON bookings
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
