import os
import uuid
from werkzeug.utils import secure_filename
from flask import current_app


def _allowed(filename, allowed_extensions):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_extensions


def save_upload(file_storage, subfolder, allowed_extensions=None):
    """
    Saves an uploaded file under UPLOAD_FOLDER/subfolder with a unique name.
    Returns the relative path (to be stored in DB) or raises ValueError.
    """
    if file_storage is None or file_storage.filename == "":
        raise ValueError("No file provided")

    allowed_extensions = allowed_extensions or current_app.config["ALLOWED_DOC_EXTENSIONS"]
    filename = secure_filename(file_storage.filename)

    if not _allowed(filename, allowed_extensions):
        raise ValueError(f"File type not allowed. Allowed: {', '.join(allowed_extensions)}")

    ext = filename.rsplit(".", 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"

    target_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], subfolder)
    os.makedirs(target_dir, exist_ok=True)

    full_path = os.path.join(target_dir, unique_name)
    file_storage.save(full_path)

    relative_path = os.path.join("uploads", subfolder, unique_name).replace("\\", "/")
    return relative_path


def delete_upload(relative_path):
    if not relative_path:
        return
    base_static = os.path.join(current_app.config["UPLOAD_FOLDER"], "..")
    full_path = os.path.normpath(os.path.join(current_app.root_path, "static", relative_path))
    if os.path.exists(full_path):
        os.remove(full_path)
