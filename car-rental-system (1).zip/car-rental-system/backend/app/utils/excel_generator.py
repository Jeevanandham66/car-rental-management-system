import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from flask import current_app


def generate_report_excel(title, headers, rows, filename):
    target_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], "reports")
    os.makedirs(target_dir, exist_ok=True)
    full_path = os.path.join(target_dir, filename)

    wb = Workbook()
    ws = wb.active
    ws.title = title[:30]

    ws.append(headers)
    header_fill = PatternFill(start_color="2563EB", end_color="2563EB", fill_type="solid")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill

    for row in rows:
        ws.append(row)

    for column_cells in ws.columns:
        max_length = max(len(str(cell.value)) if cell.value else 0 for cell in column_cells)
        ws.column_dimensions[column_cells[0].column_letter].width = max_length + 4

    wb.save(full_path)
    return os.path.join("uploads", "reports", filename).replace("\\", "/")
