import math
from datetime import datetime


def calculate_number_of_days(pickup_date, return_date):
    delta = return_date - pickup_date
    days = math.ceil(delta.total_seconds() / 86400)
    return max(days, 1)


def calculate_booking_amount(
    car,
    number_of_days,
    rental_type,
    extra_km_used=0,
    discount=0,
    gst_percentage=18,
):
    """
    Applies weekly/monthly rent slabs where beneficial, adds driver charge
    for with_driver bookings, extra KM charge, GST and discount.
    """
    daily_rent = float(car.daily_rent)
    weekly_rent = float(car.weekly_rent) if car.weekly_rent else daily_rent * 7
    monthly_rent = float(car.monthly_rent) if car.monthly_rent else daily_rent * 30

    if number_of_days >= 30 and car.monthly_rent:
        months = number_of_days // 30
        remaining_days = number_of_days % 30
        rent_amount = months * monthly_rent + remaining_days * daily_rent
    elif number_of_days >= 7 and car.weekly_rent:
        weeks = number_of_days // 7
        remaining_days = number_of_days % 7
        rent_amount = weeks * weekly_rent + remaining_days * daily_rent
    else:
        rent_amount = number_of_days * daily_rent

    driver_charge = 0.0
    if rental_type == "with_driver":
        driver_charge = number_of_days * float(car.driver_charge_per_day or 0)

    extra_km_charge_total = extra_km_used * float(car.extra_km_charge or 0)

    subtotal = rent_amount + driver_charge + extra_km_charge_total
    discount = float(discount or 0)
    taxable_amount = max(subtotal - discount, 0)
    gst_amount = round(taxable_amount * (float(gst_percentage) / 100), 2)
    total_amount = round(taxable_amount + gst_amount, 2)

    return {
        "number_of_days": number_of_days,
        "rent_amount": round(rent_amount, 2),
        "driver_charge": round(driver_charge, 2),
        "extra_km_charge_total": round(extra_km_charge_total, 2),
        "subtotal": round(subtotal, 2),
        "discount": round(discount, 2),
        "gst_percentage": float(gst_percentage),
        "gst_amount": gst_amount,
        "total_amount": total_amount,
    }


def generate_booking_number():
    return f"BK{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"


def generate_invoice_number():
    return f"INV{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
