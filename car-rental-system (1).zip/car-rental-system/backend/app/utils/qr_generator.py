import os
import qrcode
from flask import current_app


def generate_car_qr(car):
    """
    Generates a QR code encoding the car's key details / a lookup URL,
    saves it under uploads/qrcodes/, and returns the relative path.
    """
    payload = (
        f"Vehicle: {car.vehicle_number}\n"
        f"Brand/Model: {car.brand} {car.model}\n"
        f"Year: {car.manufacturing_year}\n"
        f"Car ID: {car.id}"
    )

    img = qrcode.make(payload)

    target_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], "qrcodes")
    os.makedirs(target_dir, exist_ok=True)

    filename = f"car_{car.id}_qr.png"
    full_path = os.path.join(target_dir, filename)
    img.save(full_path)

    return os.path.join("uploads", "qrcodes", filename).replace("\\", "/")
