import re
from datetime import datetime

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_REGEX = re.compile(r"^\+?[0-9]{10,15}$")
VEHICLE_NUMBER_REGEX = re.compile(r"^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{4}$")


class ValidationError(Exception):
    def __init__(self, errors):
        # errors: dict of field -> message, or a single string
        self.errors = errors if isinstance(errors, dict) else {"error": errors}
        super().__init__(str(self.errors))


def require_fields(data, fields):
    missing = [f for f in fields if data.get(f) in (None, "", [])]
    if missing:
        raise ValidationError({f: "This field is required" for f in missing})


def validate_email(email):
    if not email or not EMAIL_REGEX.match(email):
        raise ValidationError({"email": "Invalid email address"})
    return email.lower().strip()


def validate_phone(phone):
    if not phone or not PHONE_REGEX.match(phone.replace(" ", "")):
        raise ValidationError({"phone": "Invalid phone number"})
    return phone.strip()


def validate_vehicle_number(number):
    cleaned = number.replace(" ", "").upper().strip()
    if not cleaned:
        raise ValidationError({"vehicle_number": "Vehicle number is required"})
    return cleaned


def validate_date(value, field_name="date"):
    if isinstance(value, str):
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            raise ValidationError({field_name: "Invalid date format, expected YYYY-MM-DD"})
    return value


def validate_positive_number(value, field_name):
    try:
        num = float(value)
    except (TypeError, ValueError):
        raise ValidationError({field_name: "Must be a number"})
    if num < 0:
        raise ValidationError({field_name: "Must not be negative"})
    return num


def validate_choice(value, choices, field_name):
    if value not in choices:
        raise ValidationError({field_name: f"Must be one of {choices}"})
    return value
