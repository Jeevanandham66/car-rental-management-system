import os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from flask import current_app


def _output_path(subfolder, filename):
    target_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], subfolder)
    os.makedirs(target_dir, exist_ok=True)
    return os.path.join(target_dir, filename)


def generate_invoice_pdf(booking, car, owner):
    styles = getSampleStyleSheet()
    filename = f"invoice_{booking.booking_number}.pdf"
    full_path = _output_path("invoices", filename)

    doc = SimpleDocTemplate(full_path, pagesize=A4, topMargin=20 * mm)
    elements = []

    elements.append(Paragraph(f"<b>{owner.company_name or owner.full_name}</b>", styles["Title"]))
    elements.append(Paragraph(f"Invoice: {booking.invoice_number or booking.booking_number}", styles["Normal"]))
    elements.append(Spacer(1, 10))

    customer_info = [
        ["Customer Name", booking.customer_name],
        ["Phone", booking.customer_phone],
        ["Vehicle", f"{car.brand} {car.model} ({car.vehicle_number})"],
        ["Pickup Date", str(booking.pickup_date)],
        ["Return Date", str(booking.return_date)],
        ["Rental Type", booking.rental_type],
    ]
    t1 = Table(customer_info, colWidths=[150, 300])
    t1.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    elements.append(t1)
    elements.append(Spacer(1, 15))

    charges = [
        ["Description", "Amount (INR)"],
        ["Rent", f"{booking.rent_amount}"],
        ["Driver Charge", f"{booking.driver_charge}"],
        ["Extra KM Charge", f"{booking.extra_km_charge_total}"],
        ["Subtotal", f"{booking.subtotal}"],
        [f"GST ({booking.gst_percentage}%)", f"{booking.gst_amount}"],
        ["Discount", f"-{booking.discount}"],
        ["Total", f"{booking.total_amount}"],
    ]
    t2 = Table(charges, colWidths=[300, 150])
    t2.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563eb")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
            ]
        )
    )
    elements.append(t2)

    doc.build(elements)
    return os.path.join("uploads", "invoices", filename).replace("\\", "/")


def generate_car_detail_pdf(car):
    styles = getSampleStyleSheet()
    filename = f"car_{car.id}_details.pdf"
    full_path = _output_path("car_sheets", filename)

    doc = SimpleDocTemplate(full_path, pagesize=A4, topMargin=20 * mm)
    elements = [Paragraph(f"<b>Vehicle Details - {car.vehicle_number}</b>", styles["Title"]), Spacer(1, 10)]

    rows = [
        ["Brand / Model", f"{car.brand} {car.model} {car.variant or ''}"],
        ["Manufacturing Year", str(car.manufacturing_year)],
        ["Fuel Type", car.fuel_type],
        ["Transmission", car.transmission],
        ["Seating Capacity", str(car.seating_capacity)],
        ["Daily Rent", f"INR {car.daily_rent}"],
        ["Weekly Rent", f"INR {car.weekly_rent}"],
        ["Monthly Rent", f"INR {car.monthly_rent}"],
        ["Security Deposit", f"INR {car.security_deposit}"],
        ["Condition", car.condition],
        ["Availability", car.availability_status],
    ]
    t = Table(rows, colWidths=[180, 270])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey)]))
    elements.append(t)

    doc.build(elements)
    return os.path.join("uploads", "car_sheets", filename).replace("\\", "/")


def generate_report_pdf(title, headers, rows, filename):
    styles = getSampleStyleSheet()
    full_path = _output_path("reports", filename)

    doc = SimpleDocTemplate(full_path, pagesize=A4, topMargin=20 * mm)
    elements = [Paragraph(f"<b>{title}</b>", styles["Title"]), Spacer(1, 10)]

    data = [headers] + rows
    t = Table(data)
    t.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563eb")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ]
        )
    )
    elements.append(t)

    doc.build(elements)
    return os.path.join("uploads", "reports", filename).replace("\\", "/")
