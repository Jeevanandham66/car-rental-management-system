from datetime import date, timedelta

from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car
from app.models.document import VehicleDocument, DOCUMENT_TYPES
from app.utils.validators import require_fields, validate_choice, validate_date, ValidationError
from app.utils.file_upload import save_upload

documents_bp = Blueprint("documents", __name__, url_prefix="/api")


@documents_bp.errorhandler(ValidationError)
def handle_validation_error(err):
    return jsonify({"success": False, "errors": err.errors}), 400


def _compute_status(expiry_date, reminder_days):
    if not expiry_date:
        return "valid"
    today = date.today()
    if expiry_date < today:
        return "expired"
    if expiry_date <= today + timedelta(days=reminder_days or 15):
        return "expiring_soon"
    return "valid"


def _owned_car_or_404(owner_id, car_id):
    car = Car.query.filter_by(id=car_id, owner_id=owner_id).first()
    if not car:
        raise ValidationError({"error": "Car not found"})
    return car


@documents_bp.route("/cars/<int:car_id>/documents", methods=["POST"])
@jwt_required()
def upload_document(car_id):
    owner_id = get_jwt_identity()
    _owned_car_or_404(owner_id, car_id)

    document_type = request.form.get("document_type")
    validate_choice(document_type, DOCUMENT_TYPES, "document_type")

    if "file" not in request.files:
        raise ValidationError({"file": "No file uploaded"})

    relative_path = save_upload(
        request.files["file"],
        subfolder=f"cars/{car_id}/documents",
        allowed_extensions=current_app.config["ALLOWED_DOC_EXTENSIONS"],
    )

    issue_date = validate_date(request.form.get("issue_date")) if request.form.get("issue_date") else None
    expiry_date = validate_date(request.form.get("expiry_date")) if request.form.get("expiry_date") else None
    reminder_days = int(request.form.get("reminder_days_before", 15))

    doc = VehicleDocument(
        car_id=car_id,
        document_type=document_type,
        file_path=relative_path,
        issue_date=issue_date,
        expiry_date=expiry_date,
        reminder_days_before=reminder_days,
        status=_compute_status(expiry_date, reminder_days),
    )
    db.session.add(doc)
    db.session.commit()

    return jsonify({"success": True, "document": doc.to_dict()}), 201


@documents_bp.route("/cars/<int:car_id>/documents", methods=["GET"])
@jwt_required()
def list_documents(car_id):
    owner_id = get_jwt_identity()
    _owned_car_or_404(owner_id, car_id)
    docs = VehicleDocument.query.filter_by(car_id=car_id).all()
    return jsonify({"success": True, "documents": [d.to_dict() for d in docs]})


@documents_bp.route("/documents/<int:document_id>", methods=["PUT"])
@jwt_required()
def update_document(document_id):
    owner_id = get_jwt_identity()
    doc = VehicleDocument.query.get_or_404(document_id)
    _owned_car_or_404(owner_id, doc.car_id)

    data = request.get_json(force=True)
    if "issue_date" in data:
        doc.issue_date = validate_date(data["issue_date"])
    if "expiry_date" in data:
        doc.expiry_date = validate_date(data["expiry_date"])
    if "reminder_days_before" in data:
        doc.reminder_days_before = data["reminder_days_before"]

    doc.status = _compute_status(doc.expiry_date, doc.reminder_days_before)
    db.session.commit()
    return jsonify({"success": True, "document": doc.to_dict()})


@documents_bp.route("/documents/<int:document_id>", methods=["DELETE"])
@jwt_required()
def delete_document(document_id):
    owner_id = get_jwt_identity()
    doc = VehicleDocument.query.get_or_404(document_id)
    _owned_car_or_404(owner_id, doc.car_id)
    db.session.delete(doc)
    db.session.commit()
    return jsonify({"success": True, "message": "Document deleted"})


@documents_bp.route("/documents/pending", methods=["GET"])
@jwt_required()
def pending_documents():
    """Documents missing, expired, or expiring soon across all of the owner's cars."""
    owner_id = get_jwt_identity()
    car_ids = [c.id for c in Car.query.filter_by(owner_id=owner_id).all()]
    docs = VehicleDocument.query.filter(
        VehicleDocument.car_id.in_(car_ids),
        VehicleDocument.status.in_(["expired", "expiring_soon"]),
    ).all()
    return jsonify({"success": True, "documents": [d.to_dict() for d in docs]})
