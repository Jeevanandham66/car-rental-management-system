from datetime import date, timedelta

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.models.car import Car
from app.models.driver import Driver
from app.models.document import VehicleDocument

search_bp = Blueprint("search", __name__, url_prefix="/api/search")


@search_bp.route("", methods=["GET"])
@jwt_required()
def unified_search():
    owner_id = get_jwt_identity()

    vehicle_number = request.args.get("vehicle_number")
    brand = request.args.get("brand")
    driver_name = request.args.get("driver")
    availability = request.args.get("availability")
    insurance_within_days = request.args.get("insurance_expiry_within_days", type=int)
    fc_within_days = request.args.get("fc_expiry_within_days", type=int)

    results = {}

    if vehicle_number or brand or availability:
        query = Car.query.filter_by(owner_id=owner_id)
        if vehicle_number:
            query = query.filter(Car.vehicle_number.ilike(f"%{vehicle_number}%"))
        if brand:
            query = query.filter(Car.brand.ilike(f"%{brand}%"))
        if availability:
            query = query.filter_by(availability_status=availability)
        results["cars"] = [c.to_dict() for c in query.all()]

    if driver_name:
        drivers = Driver.query.filter_by(owner_id=owner_id).filter(Driver.name.ilike(f"%{driver_name}%")).all()
        results["drivers"] = [d.to_dict() for d in drivers]

    car_ids = [c.id for c in Car.query.filter_by(owner_id=owner_id).with_entities(Car.id).all()]

    if insurance_within_days is not None:
        cutoff = date.today() + timedelta(days=insurance_within_days)
        docs = VehicleDocument.query.filter(
            VehicleDocument.car_id.in_(car_ids),
            VehicleDocument.document_type == "insurance",
            VehicleDocument.expiry_date.isnot(None),
            VehicleDocument.expiry_date <= cutoff,
        ).all()
        results["insurance_expiring"] = [d.to_dict() for d in docs]

    if fc_within_days is not None:
        cutoff = date.today() + timedelta(days=fc_within_days)
        docs = VehicleDocument.query.filter(
            VehicleDocument.car_id.in_(car_ids),
            VehicleDocument.document_type == "fitness_certificate",
            VehicleDocument.expiry_date.isnot(None),
            VehicleDocument.expiry_date <= cutoff,
        ).all()
        results["fc_expiring"] = [d.to_dict() for d in docs]

    return jsonify({"success": True, "results": results})
