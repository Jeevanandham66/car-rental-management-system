from datetime import datetime

from flask import Blueprint, request, jsonify, current_app, send_from_directory
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car
from app.models.driver import Driver
from app.models.booking import Booking
from app.models.owner import Owner, OwnerSettings
from app.utils.validators import require_fields, validate_phone, validate_choice, ValidationError
from app.utils.file_upload import save_upload
from app.utils.invoice_calculator import (
    calculate_number_of_days,
    calculate_booking_amount,
    generate_booking_number,
    generate_invoice_number,
)
from app.utils.pdf_generator import generate_invoice_pdf

bookings_bp = Blueprint("bookings", __name__, url_prefix="/api/bookings")

RENTAL_TYPES = ["with_driver", "without_driver"]
BOOKING_STATUSES = ["confirmed", "ongoing", "completed", "cancelled"]


@bookings_bp.errorhandler(ValidationError)
def handle_validation_error(err):
    return jsonify({"success": False, "errors": err.errors}), 400


def _parse_datetime(value, field_name):
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        raise ValidationError({field_name: "Invalid datetime format, expected ISO 8601"})


@bookings_bp.route("", methods=["POST"])
@jwt_required()
def create_booking():
    owner_id = get_jwt_identity()
    data = request.form if request.form else request.get_json(force=True)

    require_fields(
        data,
        ["car_id", "customer_name", "customer_phone", "pickup_date", "return_date", "rental_type"],
    )

    car = Car.query.filter_by(id=data["car_id"], owner_id=owner_id).first()
    if not car:
        raise ValidationError({"car_id": "Car not found"})
    if car.availability_status not in ("available",):
        raise ValidationError({"car_id": f"Car is currently '{car.availability_status}' and not available for booking"})

    rental_type = validate_choice(data["rental_type"], RENTAL_TYPES, "rental_type")
    customer_phone = validate_phone(data["customer_phone"])

    pickup_date = _parse_datetime(data["pickup_date"], "pickup_date")
    return_date = _parse_datetime(data["return_date"], "return_date")
    if return_date <= pickup_date:
        raise ValidationError({"return_date": "Return date must be after pickup date"})

    driver_id = data.get("driver_id")
    driver = None
    if rental_type == "with_driver":
        if not driver_id:
            raise ValidationError({"driver_id": "A driver must be selected for with-driver bookings"})
        driver = Driver.query.filter_by(id=driver_id, owner_id=owner_id).first()
        if not driver:
            raise ValidationError({"driver_id": "Driver not found"})

    settings = OwnerSettings.query.filter_by(owner_id=owner_id).first()
    gst_percentage = float(settings.gst_percentage) if settings else 18

    number_of_days = calculate_number_of_days(pickup_date, return_date)
    amounts = calculate_booking_amount(
        car=car,
        number_of_days=number_of_days,
        rental_type=rental_type,
        extra_km_used=int(data.get("extra_km_used", 0)),
        discount=data.get("discount", 0),
        gst_percentage=gst_percentage,
    )

    license_path = None
    if "file" in request.files:
        license_path = save_upload(
            request.files["file"],
            subfolder="bookings/licenses",
            allowed_extensions=current_app.config["ALLOWED_DOC_EXTENSIONS"],
        )

    booking = Booking(
        owner_id=owner_id,
        car_id=car.id,
        driver_id=driver.id if driver else None,
        booking_number=generate_booking_number(),
        customer_name=data["customer_name"].strip(),
        customer_phone=customer_phone,
        customer_email=data.get("customer_email"),
        driving_license_upload=license_path,
        pickup_date=pickup_date,
        return_date=return_date,
        pickup_location=data.get("pickup_location"),
        drop_location=data.get("drop_location"),
        rental_type=rental_type,
        number_of_days=amounts["number_of_days"],
        rent_amount=amounts["rent_amount"],
        driver_charge=amounts["driver_charge"],
        extra_km_used=int(data.get("extra_km_used", 0)),
        extra_km_charge_total=amounts["extra_km_charge_total"],
        subtotal=amounts["subtotal"],
        gst_percentage=amounts["gst_percentage"],
        gst_amount=amounts["gst_amount"],
        discount=amounts["discount"],
        total_amount=amounts["total_amount"],
        security_deposit_collected=data.get("security_deposit_collected", 0),
        invoice_number=generate_invoice_number(),
    )
    db.session.add(booking)

    car.availability_status = "booked"
    if driver:
        driver.status = "on_trip"

    db.session.commit()

    return jsonify({"success": True, "booking": booking.to_dict()}), 201


@bookings_bp.route("", methods=["GET"])
@jwt_required()
def list_bookings():
    owner_id = get_jwt_identity()
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 20, type=int), 100)

    query = Booking.query.filter_by(owner_id=owner_id)

    status = request.args.get("status")
    if status:
        query = query.filter_by(status=status)

    car_id = request.args.get("car_id")
    if car_id:
        query = query.filter_by(car_id=car_id)

    search = request.args.get("search")
    if search:
        query = query.filter(
            db.or_(
                Booking.customer_name.ilike(f"%{search}%"),
                Booking.booking_number.ilike(f"%{search}%"),
                Booking.customer_phone.ilike(f"%{search}%"),
            )
        )

    pagination = query.order_by(Booking.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    return jsonify(
        {
            "success": True,
            "bookings": [b.to_dict() for b in pagination.items],
            "total": pagination.total,
            "page": page,
            "pages": pagination.pages,
        }
    )


@bookings_bp.route("/<int:booking_id>", methods=["GET"])
@jwt_required()
def get_booking(booking_id):
    owner_id = get_jwt_identity()
    booking = Booking.query.filter_by(id=booking_id, owner_id=owner_id).first_or_404()
    return jsonify({"success": True, "booking": booking.to_dict()})


@bookings_bp.route("/<int:booking_id>/status", methods=["PUT"])
@jwt_required()
def update_booking_status(booking_id):
    owner_id = get_jwt_identity()
    booking = Booking.query.filter_by(id=booking_id, owner_id=owner_id).first_or_404()
    data = request.get_json(force=True)
    require_fields(data, ["status"])
    new_status = validate_choice(data["status"], BOOKING_STATUSES, "status")

    booking.status = new_status
    car = Car.query.get(booking.car_id)

    if new_status in ("completed", "cancelled"):
        if car:
            car.availability_status = "available"
        if booking.driver_id:
            driver = Driver.query.get(booking.driver_id)
            if driver:
                driver.status = "active"
    elif new_status == "ongoing":
        if car:
            car.availability_status = "booked"

    db.session.commit()
    return jsonify({"success": True, "booking": booking.to_dict()})


@bookings_bp.route("/<int:booking_id>/invoice", methods=["GET"])
@jwt_required()
def download_invoice(booking_id):
    owner_id = get_jwt_identity()
    booking = Booking.query.filter_by(id=booking_id, owner_id=owner_id).first_or_404()
    car = Car.query.get(booking.car_id)
    owner = Owner.query.get(owner_id)

    relative_path = generate_invoice_pdf(booking, car, owner)
    booking.invoice_pdf_path = relative_path
    db.session.commit()

    directory = current_app.config["UPLOAD_FOLDER"] + "/invoices"
    filename = relative_path.split("/")[-1]
    return send_from_directory(directory, filename, as_attachment=True)
