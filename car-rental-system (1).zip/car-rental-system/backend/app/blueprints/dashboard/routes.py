from datetime import date, timedelta
from sqlalchemy import func, extract

from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car
from app.models.booking import Booking
from app.models.document import VehicleDocument

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


@dashboard_bp.route("/summary", methods=["GET"])
@jwt_required()
def summary():
    owner_id = get_jwt_identity()
    today = date.today()
    month_start = today.replace(day=1)

    total_cars = Car.query.filter_by(owner_id=owner_id).count()
    cars_available = Car.query.filter_by(owner_id=owner_id, availability_status="available").count()
    cars_booked = Car.query.filter_by(owner_id=owner_id, availability_status="booked").count()
    cars_service = Car.query.filter_by(owner_id=owner_id, availability_status="service").count()

    monthly_revenue = (
        db.session.query(func.coalesce(func.sum(Booking.total_amount), 0))
        .filter(
            Booking.owner_id == owner_id,
            Booking.status != "cancelled",
            extract("year", Booking.created_at) == today.year,
            extract("month", Booking.created_at) == today.month,
        )
        .scalar()
    )

    todays_bookings = Booking.query.filter(
        Booking.owner_id == owner_id,
        func.date(Booking.pickup_date) == today,
    ).count()

    car_ids = [c.id for c in Car.query.filter_by(owner_id=owner_id).with_entities(Car.id).all()]
    pending_documents = VehicleDocument.query.filter(
        VehicleDocument.car_id.in_(car_ids),
        VehicleDocument.status.in_(["expired", "expiring_soon"]),
    ).count()

    upcoming_insurance = (
        VehicleDocument.query.filter(
            VehicleDocument.car_id.in_(car_ids),
            VehicleDocument.document_type == "insurance",
            VehicleDocument.expiry_date.isnot(None),
            VehicleDocument.expiry_date.between(today, today + timedelta(days=30)),
        )
        .order_by(VehicleDocument.expiry_date.asc())
        .all()
    )

    upcoming_fc = (
        VehicleDocument.query.filter(
            VehicleDocument.car_id.in_(car_ids),
            VehicleDocument.document_type == "fitness_certificate",
            VehicleDocument.expiry_date.isnot(None),
            VehicleDocument.expiry_date.between(today, today + timedelta(days=30)),
        )
        .order_by(VehicleDocument.expiry_date.asc())
        .all()
    )

    return jsonify(
        {
            "success": True,
            "summary": {
                "total_cars": total_cars,
                "cars_available": cars_available,
                "cars_booked": cars_booked,
                "cars_under_service": cars_service,
                "monthly_revenue": float(monthly_revenue or 0),
                "todays_bookings": todays_bookings,
                "pending_documents": pending_documents,
                "upcoming_insurance_expiry": [d.to_dict() for d in upcoming_insurance],
                "upcoming_fc_expiry": [d.to_dict() for d in upcoming_fc],
            },
        }
    )
