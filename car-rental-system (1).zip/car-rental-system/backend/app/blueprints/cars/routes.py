from flask import Blueprint, request, jsonify, send_from_directory, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car, CarInspectionChecklist, CarImage
from app.utils.validators import (
    require_fields,
    validate_vehicle_number,
    validate_choice,
    validate_positive_number,
    ValidationError,
)
from app.utils.file_upload import save_upload
from app.utils.qr_generator import generate_car_qr
from app.utils.pdf_generator import generate_car_detail_pdf

cars_bp = Blueprint("cars", __name__, url_prefix="/api/cars")

FUEL_TYPES = ["Petrol", "Diesel", "CNG", "Electric", "Hybrid"]
TRANSMISSIONS = ["Manual", "Automatic"]
DRIVER_OPTIONS = ["with_driver", "without_driver", "both"]
AVAILABILITY_STATUSES = ["available", "booked", "service", "inactive"]
CONDITIONS = ["excellent", "very_good", "good", "needs_service"]
IMAGE_TYPES = ["front", "rear", "left", "right", "interior", "dashboard", "engine", "tyres"]


@cars_bp.errorhandler(ValidationError)
def handle_validation_error(err):
    return jsonify({"success": False, "errors": err.errors}), 400


def _owned_car_or_404(owner_id, car_id):
    car = Car.query.filter_by(id=car_id, owner_id=owner_id).first()
    if not car:
        raise ValidationError({"error": "Car not found"})
    return car


@cars_bp.route("", methods=["POST"])
@jwt_required()
def create_car():
    owner_id = get_jwt_identity()
    data = request.get_json(force=True)

    require_fields(
        data,
        ["vehicle_number", "brand", "model", "manufacturing_year", "fuel_type",
         "transmission", "daily_rent"],
    )

    vehicle_number = validate_vehicle_number(data["vehicle_number"])
    if Car.query.filter_by(vehicle_number=vehicle_number).first():
        raise ValidationError({"vehicle_number": "A car with this number already exists"})

    validate_choice(data["fuel_type"], FUEL_TYPES, "fuel_type")
    validate_choice(data["transmission"], TRANSMISSIONS, "transmission")
    validate_choice(data.get("driver_option", "both"), DRIVER_OPTIONS, "driver_option")
    validate_choice(data.get("availability_status", "available"), AVAILABILITY_STATUSES, "availability_status")
    validate_choice(data.get("condition", "good"), CONDITIONS, "condition")
    validate_positive_number(data["daily_rent"], "daily_rent")

    car = Car(
        owner_id=owner_id,
        vehicle_number=vehicle_number,
        brand=data["brand"].strip(),
        model=data["model"].strip(),
        variant=data.get("variant"),
        manufacturing_year=data["manufacturing_year"],
        fuel_type=data["fuel_type"],
        transmission=data["transmission"],
        color=data.get("color"),
        engine_number=data.get("engine_number"),
        chassis_number=data.get("chassis_number"),
        odometer_reading=data.get("odometer_reading", 0),
        mileage=data.get("mileage"),
        seating_capacity=data.get("seating_capacity", 4),
        daily_rent=data["daily_rent"],
        weekly_rent=data.get("weekly_rent"),
        monthly_rent=data.get("monthly_rent"),
        security_deposit=data.get("security_deposit", 0),
        extra_km_charge=data.get("extra_km_charge", 0),
        night_charge=data.get("night_charge", 0),
        driver_charge_per_day=data.get("driver_charge_per_day", 0),
        driver_option=data.get("driver_option", "both"),
        availability_status=data.get("availability_status", "available"),
        condition=data.get("condition", "good"),
    )
    db.session.add(car)
    db.session.flush()

    checklist_data = data.get("checklist", {})
    checklist = CarInspectionChecklist(
        car_id=car.id,
        engine_ok=checklist_data.get("engine_ok", False),
        brakes_ok=checklist_data.get("brakes_ok", False),
        tyres_ok=checklist_data.get("tyres_ok", False),
        battery_ok=checklist_data.get("battery_ok", False),
        lights_ok=checklist_data.get("lights_ok", False),
        horn_ok=checklist_data.get("horn_ok", False),
        ac_ok=checklist_data.get("ac_ok", False),
        seat_covers_ok=checklist_data.get("seat_covers_ok", False),
        music_system_ok=checklist_data.get("music_system_ok", False),
        gps_ok=checklist_data.get("gps_ok", False),
    )
    db.session.add(checklist)
    db.session.commit()

    return jsonify({"success": True, "car": car.to_dict(include_relations=True)}), 201


@cars_bp.route("", methods=["GET"])
@jwt_required()
def list_cars():
    owner_id = get_jwt_identity()
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 20, type=int), 100)

    query = Car.query.filter_by(owner_id=owner_id)

    availability = request.args.get("availability_status")
    if availability:
        query = query.filter_by(availability_status=availability)

    brand = request.args.get("brand")
    if brand:
        query = query.filter(Car.brand.ilike(f"%{brand}%"))

    search = request.args.get("search")
    if search:
        query = query.filter(Car.vehicle_number.ilike(f"%{search}%"))

    query = query.order_by(Car.created_at.desc())
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)

    return jsonify(
        {
            "success": True,
            "cars": [c.to_dict() for c in pagination.items],
            "total": pagination.total,
            "page": page,
            "pages": pagination.pages,
        }
    )


@cars_bp.route("/<int:car_id>", methods=["GET"])
@jwt_required()
def get_car(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    return jsonify({"success": True, "car": car.to_dict(include_relations=True)})


@cars_bp.route("/<int:car_id>", methods=["PUT"])
@jwt_required()
def update_car(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    data = request.get_json(force=True)

    editable_fields = [
        "brand", "model", "variant", "manufacturing_year", "fuel_type", "transmission",
        "color", "engine_number", "chassis_number", "odometer_reading", "mileage",
        "seating_capacity", "daily_rent", "weekly_rent", "monthly_rent", "security_deposit",
        "extra_km_charge", "night_charge", "driver_charge_per_day", "driver_option",
        "availability_status", "condition",
    ]
    for field in editable_fields:
        if field in data:
            setattr(car, field, data[field])

    if "vehicle_number" in data:
        new_number = validate_vehicle_number(data["vehicle_number"])
        if new_number != car.vehicle_number and Car.query.filter_by(vehicle_number=new_number).first():
            raise ValidationError({"vehicle_number": "A car with this number already exists"})
        car.vehicle_number = new_number

    db.session.commit()
    return jsonify({"success": True, "car": car.to_dict(include_relations=True)})


@cars_bp.route("/<int:car_id>", methods=["DELETE"])
@jwt_required()
def delete_car(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    db.session.delete(car)
    db.session.commit()
    return jsonify({"success": True, "message": "Car deleted"})


@cars_bp.route("/<int:car_id>/checklist", methods=["PUT"])
@jwt_required()
def update_checklist(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    data = request.get_json(force=True)

    checklist = car.checklist or CarInspectionChecklist(car_id=car.id)
    fields = [
        "engine_ok", "brakes_ok", "tyres_ok", "battery_ok", "lights_ok",
        "horn_ok", "ac_ok", "seat_covers_ok", "music_system_ok", "gps_ok",
    ]
    for f in fields:
        if f in data:
            setattr(checklist, f, bool(data[f]))

    db.session.add(checklist)
    db.session.commit()
    return jsonify({"success": True, "checklist": checklist.to_dict()})


@cars_bp.route("/<int:car_id>/images", methods=["POST"])
@jwt_required()
def upload_car_image(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)

    image_type = request.form.get("image_type")
    validate_choice(image_type, IMAGE_TYPES, "image_type")

    if "file" not in request.files:
        raise ValidationError({"file": "No file uploaded"})

    relative_path = save_upload(
        request.files["file"],
        subfolder=f"cars/{car.id}/images",
        allowed_extensions=current_app.config["ALLOWED_IMAGE_EXTENSIONS"],
    )

    # Replace existing image of the same type if present
    existing = CarImage.query.filter_by(car_id=car.id, image_type=image_type).first()
    if existing:
        existing.file_path = relative_path
    else:
        db.session.add(CarImage(car_id=car.id, image_type=image_type, file_path=relative_path))

    db.session.commit()
    return jsonify({"success": True, "images": [img.to_dict() for img in car.images]})


@cars_bp.route("/<int:car_id>/qrcode", methods=["POST"])
@jwt_required()
def generate_qrcode(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    relative_path = generate_car_qr(car)
    return jsonify({"success": True, "qr_code_path": relative_path})


@cars_bp.route("/<int:car_id>/pdf", methods=["GET"])
@jwt_required()
def download_car_pdf(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    relative_path = generate_car_detail_pdf(car)
    directory = current_app.config["UPLOAD_FOLDER"] + "/car_sheets"
    filename = relative_path.split("/")[-1]
    return send_from_directory(directory, filename, as_attachment=True)
