from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car
from app.models.service import ServiceRecord
from app.utils.validators import require_fields, validate_date, ValidationError
from app.utils.file_upload import save_upload

service_bp = Blueprint("service", __name__, url_prefix="/api")


@service_bp.errorhandler(ValidationError)
def handle_validation_error(err):
    return jsonify({"success": False, "errors": err.errors}), 400


def _owned_car_or_404(owner_id, car_id):
    car = Car.query.filter_by(id=car_id, owner_id=owner_id).first()
    if not car:
        raise ValidationError({"error": "Car not found"})
    return car


@service_bp.route("/cars/<int:car_id>/service-records", methods=["POST"])
@jwt_required()
def create_service_record(car_id):
    owner_id = get_jwt_identity()
    car = _owned_car_or_404(owner_id, car_id)
    data = request.form if request.form else request.get_json(force=True)

    require_fields(data, ["service_date"])
    service_date = validate_date(data["service_date"], "service_date")

    bill_path = None
    if "file" in request.files:
        bill_path = save_upload(
            request.files["file"],
            subfolder=f"cars/{car_id}/service_bills",
            allowed_extensions=current_app.config["ALLOWED_DOC_EXTENSIONS"],
        )

    next_due_date = data.get("next_service_due_date")
    record = ServiceRecord(
        car_id=car.id,
        service_date=service_date,
        service_center=data.get("service_center"),
        service_type=data.get("service_type"),
        cost=data.get("cost", 0),
        odometer_reading=data.get("odometer_reading"),
        next_service_due_date=validate_date(next_due_date, "next_service_due_date") if next_due_date else None,
        next_service_due_km=data.get("next_service_due_km"),
        bill_upload=bill_path,
        notes=data.get("notes"),
    )
    db.session.add(record)

    if data.get("odometer_reading"):
        car.odometer_reading = int(data["odometer_reading"])
    if data.get("update_condition"):
        car.condition = data["update_condition"]

    db.session.commit()
    return jsonify({"success": True, "service_record": record.to_dict()}), 201


@service_bp.route("/cars/<int:car_id>/service-records", methods=["GET"])
@jwt_required()
def list_service_records(car_id):
    owner_id = get_jwt_identity()
    _owned_car_or_404(owner_id, car_id)
    records = ServiceRecord.query.filter_by(car_id=car_id).order_by(ServiceRecord.service_date.desc()).all()
    return jsonify({"success": True, "service_records": [r.to_dict() for r in records]})


@service_bp.route("/service-records/<int:record_id>", methods=["PUT"])
@jwt_required()
def update_service_record(record_id):
    owner_id = get_jwt_identity()
    record = ServiceRecord.query.get_or_404(record_id)
    _owned_car_or_404(owner_id, record.car_id)

    data = request.get_json(force=True)
    editable = ["service_center", "service_type", "cost", "odometer_reading", "next_service_due_km", "notes"]
    for f in editable:
        if f in data:
            setattr(record, f, data[f])
    if "service_date" in data:
        record.service_date = validate_date(data["service_date"], "service_date")
    if "next_service_due_date" in data:
        record.next_service_due_date = validate_date(data["next_service_due_date"], "next_service_due_date")

    db.session.commit()
    return jsonify({"success": True, "service_record": record.to_dict()})


@service_bp.route("/service-records/<int:record_id>", methods=["DELETE"])
@jwt_required()
def delete_service_record(record_id):
    owner_id = get_jwt_identity()
    record = ServiceRecord.query.get_or_404(record_id)
    _owned_car_or_404(owner_id, record.car_id)
    db.session.delete(record)
    db.session.commit()
    return jsonify({"success": True, "message": "Service record deleted"})
