from datetime import date, datetime
from sqlalchemy import func, extract

from flask import Blueprint, request, jsonify, current_app, send_from_directory
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car
from app.models.booking import Booking
from app.models.service import ServiceRecord
from app.utils.pdf_generator import generate_report_pdf
from app.utils.excel_generator import generate_report_excel

reports_bp = Blueprint("reports", __name__, url_prefix="/api/reports")


@reports_bp.route("/monthly-revenue", methods=["GET"])
@jwt_required()
def monthly_revenue():
    owner_id = get_jwt_identity()
    year = request.args.get("year", date.today().year, type=int)

    rows = (
        db.session.query(
            extract("month", Booking.created_at).label("month"),
            func.coalesce(func.sum(Booking.total_amount), 0).label("revenue"),
        )
        .filter(Booking.owner_id == owner_id, Booking.status != "cancelled", extract("year", Booking.created_at) == year)
        .group_by("month")
        .order_by("month")
        .all()
    )
    data = [{"month": int(r.month), "revenue": float(r.revenue)} for r in rows]
    return jsonify({"success": True, "year": year, "monthly_revenue": data})


@reports_bp.route("/yearly-revenue", methods=["GET"])
@jwt_required()
def yearly_revenue():
    owner_id = get_jwt_identity()

    rows = (
        db.session.query(
            extract("year", Booking.created_at).label("year"),
            func.coalesce(func.sum(Booking.total_amount), 0).label("revenue"),
        )
        .filter(Booking.owner_id == owner_id, Booking.status != "cancelled")
        .group_by("year")
        .order_by("year")
        .all()
    )
    data = [{"year": int(r.year), "revenue": float(r.revenue)} for r in rows]
    return jsonify({"success": True, "yearly_revenue": data})


@reports_bp.route("/car-utilization", methods=["GET"])
@jwt_required()
def car_utilization():
    owner_id = get_jwt_identity()

    rows = (
        db.session.query(
            Car.id, Car.vehicle_number, Car.brand, Car.model,
            func.count(Booking.id).label("total_bookings"),
            func.coalesce(func.sum(Booking.number_of_days), 0).label("total_days_booked"),
        )
        .outerjoin(Booking, Booking.car_id == Car.id)
        .filter(Car.owner_id == owner_id)
        .group_by(Car.id)
        .order_by(func.count(Booking.id).desc())
        .all()
    )
    data = [
        {
            "car_id": r.id,
            "vehicle_number": r.vehicle_number,
            "brand": r.brand,
            "model": r.model,
            "total_bookings": r.total_bookings,
            "total_days_booked": r.total_days_booked,
        }
        for r in rows
    ]
    return jsonify({"success": True, "car_utilization": data})


@reports_bp.route("/most-booked-vehicle", methods=["GET"])
@jwt_required()
def most_booked_vehicle():
    owner_id = get_jwt_identity()

    row = (
        db.session.query(
            Car.id, Car.vehicle_number, Car.brand, Car.model,
            func.count(Booking.id).label("total_bookings"),
        )
        .join(Booking, Booking.car_id == Car.id)
        .filter(Car.owner_id == owner_id)
        .group_by(Car.id)
        .order_by(func.count(Booking.id).desc())
        .first()
    )
    if not row:
        return jsonify({"success": True, "most_booked_vehicle": None})

    return jsonify(
        {
            "success": True,
            "most_booked_vehicle": {
                "car_id": row.id,
                "vehicle_number": row.vehicle_number,
                "brand": row.brand,
                "model": row.model,
                "total_bookings": row.total_bookings,
            },
        }
    )


@reports_bp.route("/service-cost", methods=["GET"])
@jwt_required()
def service_cost_report():
    owner_id = get_jwt_identity()

    rows = (
        db.session.query(
            Car.id, Car.vehicle_number, Car.brand, Car.model,
            func.coalesce(func.sum(ServiceRecord.cost), 0).label("total_service_cost"),
            func.count(ServiceRecord.id).label("service_count"),
        )
        .outerjoin(ServiceRecord, ServiceRecord.car_id == Car.id)
        .filter(Car.owner_id == owner_id)
        .group_by(Car.id)
        .order_by(func.coalesce(func.sum(ServiceRecord.cost), 0).desc())
        .all()
    )
    data = [
        {
            "car_id": r.id,
            "vehicle_number": r.vehicle_number,
            "brand": r.brand,
            "model": r.model,
            "total_service_cost": float(r.total_service_cost),
            "service_count": r.service_count,
        }
        for r in rows
    ]
    return jsonify({"success": True, "service_cost_report": data})


@reports_bp.route("/export/<string:report_type>", methods=["GET"])
@jwt_required()
def export_report(report_type):
    owner_id = get_jwt_identity()
    fmt = request.args.get("format", "pdf")  # pdf or excel

    generators = {
        "car-utilization": _build_car_utilization_rows,
        "service-cost": _build_service_cost_rows,
        "monthly-revenue": _build_monthly_revenue_rows,
    }
    if report_type not in generators:
        return jsonify({"success": False, "error": "Unknown report type"}), 400

    title, headers, rows = generators[report_type](owner_id)
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")

    if fmt == "excel":
        filename = f"{report_type}_{timestamp}.xlsx"
        relative_path = generate_report_excel(title, headers, rows, filename)
    else:
        filename = f"{report_type}_{timestamp}.pdf"
        relative_path = generate_report_pdf(title, headers, [[str(c) for c in row] for row in rows], filename)

    directory = current_app.config["UPLOAD_FOLDER"] + "/reports"
    return send_from_directory(directory, filename, as_attachment=True)


def _build_car_utilization_rows(owner_id):
    rows = (
        db.session.query(
            Car.vehicle_number, Car.brand, Car.model,
            func.count(Booking.id), func.coalesce(func.sum(Booking.number_of_days), 0),
        )
        .outerjoin(Booking, Booking.car_id == Car.id)
        .filter(Car.owner_id == owner_id)
        .group_by(Car.id)
        .all()
    )
    headers = ["Vehicle Number", "Brand", "Model", "Total Bookings", "Total Days Booked"]
    return "Car Utilization Report", headers, [list(r) for r in rows]


def _build_service_cost_rows(owner_id):
    rows = (
        db.session.query(
            Car.vehicle_number, Car.brand, Car.model,
            func.coalesce(func.sum(ServiceRecord.cost), 0), func.count(ServiceRecord.id),
        )
        .outerjoin(ServiceRecord, ServiceRecord.car_id == Car.id)
        .filter(Car.owner_id == owner_id)
        .group_by(Car.id)
        .all()
    )
    headers = ["Vehicle Number", "Brand", "Model", "Total Service Cost", "Service Count"]
    return "Service Cost Report", headers, [list(r) for r in rows]


def _build_monthly_revenue_rows(owner_id):
    year = date.today().year
    rows = (
        db.session.query(
            extract("month", Booking.created_at), func.coalesce(func.sum(Booking.total_amount), 0)
        )
        .filter(Booking.owner_id == owner_id, Booking.status != "cancelled", extract("year", Booking.created_at) == year)
        .group_by(extract("month", Booking.created_at))
        .order_by(extract("month", Booking.created_at))
        .all()
    )
    headers = ["Month", "Revenue"]
    return f"Monthly Revenue Report {year}", headers, [[int(m), float(rev)] for m, rev in rows]
