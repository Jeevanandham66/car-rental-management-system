from datetime import date, timedelta

from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.car import Car
from app.models.driver import Driver
from app.models.document import VehicleDocument
from app.models.service import ServiceRecord
from app.models.owner import OwnerSettings

notifications_bp = Blueprint("notifications", __name__, url_prefix="/api/notifications")


@notifications_bp.route("", methods=["GET"])
@jwt_required()
def list_notifications():
    """
    Computes live reminders (not persisted) for: insurance expiry, FC expiry,
    license expiry, permit expiry, and upcoming service due, based on the
    owner's configured notification window.
    """
    owner_id = get_jwt_identity()
    settings = OwnerSettings.query.filter_by(owner_id=owner_id).first()
    window_days = settings.notification_days if settings else 15
    today = date.today()
    cutoff = today + timedelta(days=window_days)

    car_ids = [c.id for c in Car.query.filter_by(owner_id=owner_id).with_entities(Car.id).all()]
    notifications = []

    doc_type_labels = {
        "insurance": "insurance_expiry",
        "fitness_certificate": "fc_expiry",
        "permit": "permit_expiry",
    }
    docs = VehicleDocument.query.filter(
        VehicleDocument.car_id.in_(car_ids),
        VehicleDocument.document_type.in_(list(doc_type_labels.keys())),
        VehicleDocument.expiry_date.isnot(None),
        VehicleDocument.expiry_date <= cutoff,
    ).all()
    for d in docs:
        car = Car.query.get(d.car_id)
        notifications.append(
            {
                "type": doc_type_labels[d.document_type],
                "title": f"{d.document_type.replace('_', ' ').title()} expiring for {car.vehicle_number if car else ''}",
                "due_date": d.expiry_date.isoformat(),
                "reference_id": d.id,
                "is_overdue": d.expiry_date < today,
            }
        )

    drivers = Driver.query.filter(
        Driver.owner_id == owner_id,
        Driver.license_expiry <= cutoff,
    ).all()
    for drv in drivers:
        notifications.append(
            {
                "type": "license_expiry",
                "title": f"Driving license expiring for {drv.name}",
                "due_date": drv.license_expiry.isoformat(),
                "reference_id": drv.id,
                "is_overdue": drv.license_expiry < today,
            }
        )

    due_services = ServiceRecord.query.filter(
        ServiceRecord.car_id.in_(car_ids),
        ServiceRecord.next_service_due_date.isnot(None),
        ServiceRecord.next_service_due_date <= cutoff,
    ).all()
    for s in due_services:
        car = Car.query.get(s.car_id)
        notifications.append(
            {
                "type": "service_due",
                "title": f"Service due for {car.vehicle_number if car else ''}",
                "due_date": s.next_service_due_date.isoformat(),
                "reference_id": s.id,
                "is_overdue": s.next_service_due_date < today,
            }
        )

    notifications.sort(key=lambda n: n["due_date"])
    return jsonify({"success": True, "notifications": notifications, "window_days": window_days})
