import secrets
from datetime import datetime, timedelta

from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt_identity,
)

from app.extensions import db, bcrypt
from app.models.owner import Owner, OwnerSettings
from app.utils.validators import (
    require_fields,
    validate_email,
    validate_phone,
    ValidationError,
)

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.errorhandler(ValidationError)
def handle_validation_error(err):
    return jsonify({"success": False, "errors": err.errors}), 400


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(force=True)
    require_fields(data, ["full_name", "email", "phone", "password"])

    email = validate_email(data["email"])
    phone = validate_phone(data["phone"])

    if len(data["password"]) < 8:
        raise ValidationError({"password": "Password must be at least 8 characters"})

    if Owner.query.filter_by(email=email).first():
        raise ValidationError({"email": "An account with this email already exists"})
    if Owner.query.filter_by(phone=phone).first():
        raise ValidationError({"phone": "An account with this phone already exists"})

    password_hash = bcrypt.generate_password_hash(data["password"]).decode("utf-8")

    owner = Owner(
        full_name=data["full_name"].strip(),
        email=email,
        phone=phone,
        password_hash=password_hash,
        company_name=data.get("company_name"),
    )
    db.session.add(owner)
    db.session.flush()

    settings = OwnerSettings(owner_id=owner.id)
    db.session.add(settings)
    db.session.commit()

    access_token = create_access_token(identity=str(owner.id))
    refresh_token = create_refresh_token(identity=str(owner.id))

    return jsonify(
        {
            "success": True,
            "owner": owner.to_dict(),
            "access_token": access_token,
            "refresh_token": refresh_token,
        }
    ), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    require_fields(data, ["email", "password"])

    owner = Owner.query.filter_by(email=data["email"].lower().strip()).first()
    if not owner or not bcrypt.check_password_hash(owner.password_hash, data["password"]):
        raise ValidationError({"error": "Invalid email or password"})

    if not owner.is_active:
        raise ValidationError({"error": "This account has been deactivated"})

    access_token = create_access_token(identity=str(owner.id))
    refresh_token = create_refresh_token(identity=str(owner.id))

    return jsonify(
        {
            "success": True,
            "owner": owner.to_dict(),
            "access_token": access_token,
            "refresh_token": refresh_token,
        }
    )


@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    access_token = create_access_token(identity=identity)
    return jsonify({"success": True, "access_token": access_token})


@auth_bp.route("/forgot-password", methods=["POST"])
def forgot_password():
    data = request.get_json(force=True)
    require_fields(data, ["email"])

    owner = Owner.query.filter_by(email=data["email"].lower().strip()).first()
    # Always return success to avoid leaking which emails are registered
    if owner:
        token = secrets.token_urlsafe(32)
        owner.reset_token = token
        owner.reset_token_expiry = datetime.utcnow() + timedelta(hours=1)
        db.session.commit()
        # In production: send `token` via email using Flask-Mail here.

    return jsonify(
        {"success": True, "message": "If that email exists, a reset link has been sent."}
    )


@auth_bp.route("/reset-password", methods=["POST"])
def reset_password():
    data = request.get_json(force=True)
    require_fields(data, ["token", "new_password"])

    if len(data["new_password"]) < 8:
        raise ValidationError({"new_password": "Password must be at least 8 characters"})

    owner = Owner.query.filter_by(reset_token=data["token"]).first()
    if not owner or not owner.reset_token_expiry or owner.reset_token_expiry < datetime.utcnow():
        raise ValidationError({"token": "Invalid or expired reset token"})

    owner.password_hash = bcrypt.generate_password_hash(data["new_password"]).decode("utf-8")
    owner.reset_token = None
    owner.reset_token_expiry = None
    db.session.commit()

    return jsonify({"success": True, "message": "Password has been reset. Please log in."})


@auth_bp.route("/me", methods=["GET"])
@jwt_required()
def me():
    owner_id = get_jwt_identity()
    owner = Owner.query.get_or_404(owner_id)
    return jsonify({"success": True, "owner": owner.to_dict()})


@auth_bp.route("/me", methods=["PUT"])
@jwt_required()
def update_profile():
    owner_id = get_jwt_identity()
    owner = Owner.query.get_or_404(owner_id)
    data = request.get_json(force=True)

    if "full_name" in data:
        owner.full_name = data["full_name"].strip()
    if "company_name" in data:
        owner.company_name = data["company_name"]
    if "phone" in data:
        owner.phone = validate_phone(data["phone"])

    db.session.commit()
    return jsonify({"success": True, "owner": owner.to_dict()})
