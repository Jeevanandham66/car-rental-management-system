from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.driver import Driver, DriverAssignment
from app.models.car import Car
from app.utils.validators import require_fields, validate_phone, validate_date, validate_choice, ValidationError
from app.utils.file_upload import save_upload

drivers_bp = Blueprint("drivers", __name__, url_prefix="/api/drivers")

DRIVER_STATUSES = ["active", "inactive", "on_trip"]


@drivers_bp.errorhandler(ValidationError)
def handle_validation_error(err):
    return jsonify({"success": False, "errors": err.errors}), 400


def _owned_driver_or_404(owner_id, driver_id):
    driver = Driver.query.filter_by(id=driver_id, owner_id=owner_id).first()
    if not driver:
        raise ValidationError({"error": "Driver not found"})
    return driver


@drivers_bp.route("", methods=["POST"])
@jwt_required()
def create_driver():
    owner_id = get_jwt_identity()
    data = request.get_json(force=True)
    require_fields(data, ["name", "phone", "license_number", "license_expiry"])

    phone = validate_phone(data["phone"])
    license_expiry = validate_date(data["license_expiry"], "license_expiry")

    if Driver.query.filter_by(license_number=data["license_number"]).first():
        raise ValidationError({"license_number": "A driver with this license number already exists"})

    driver = Driver(
        owner_id=owner_id,
        name=data["name"].strip(),
        phone=phone,
        license_number=data["license_number"].strip(),
        license_expiry=license_expiry,
        address=data.get("address"),
        aadhar_number=data.get("aadhar_number"),
        experience_years=data.get("experience_years"),
        salary=data.get("salary"),
        status=data.get("status", "active"),
    )
    db.session.add(driver)
    db.session.commit()
    return jsonify({"success": True, "driver": driver.to_dict()}), 201


@drivers_bp.route("", methods=["GET"])
@jwt_required()
def list_drivers():
    owner_id = get_jwt_identity()
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 20, type=int), 100)

    query = Driver.query.filter_by(owner_id=owner_id)

    status = request.args.get("status")
    if status:
        query = query.filter_by(status=status)

    search = request.args.get("search")
    if search:
        query = query.filter(Driver.name.ilike(f"%{search}%"))

    pagination = query.order_by(Driver.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    return jsonify(
        {
            "success": True,
            "drivers": [d.to_dict() for d in pagination.items],
            "total": pagination.total,
            "page": page,
            "pages": pagination.pages,
        }
    )


@drivers_bp.route("/<int:driver_id>", methods=["GET"])
@jwt_required()
def get_driver(driver_id):
    owner_id = get_jwt_identity()
    driver = _owned_driver_or_404(owner_id, driver_id)
    return jsonify({"success": True, "driver": driver.to_dict()})


@drivers_bp.route("/<int:driver_id>", methods=["PUT"])
@jwt_required()
def update_driver(driver_id):
    owner_id = get_jwt_identity()
    driver = _owned_driver_or_404(owner_id, driver_id)
    data = request.get_json(force=True)

    editable = ["name", "address", "aadhar_number", "experience_years", "salary"]
    for f in editable:
        if f in data:
            setattr(driver, f, data[f])

    if "phone" in data:
        driver.phone = validate_phone(data["phone"])
    if "license_expiry" in data:
        driver.license_expiry = validate_date(data["license_expiry"], "license_expiry")
    if "status" in data:
        driver.status = validate_choice(data["status"], DRIVER_STATUSES, "status")

    db.session.commit()
    return jsonify({"success": True, "driver": driver.to_dict()})


@drivers_bp.route("/<int:driver_id>", methods=["DELETE"])
@jwt_required()
def delete_driver(driver_id):
    owner_id = get_jwt_identity()
    driver = _owned_driver_or_404(owner_id, driver_id)
    db.session.delete(driver)
    db.session.commit()
    return jsonify({"success": True, "message": "Driver deleted"})


@drivers_bp.route("/<int:driver_id>/photo", methods=["POST"])
@jwt_required()
def upload_driver_photo(driver_id):
    owner_id = get_jwt_identity()
    driver = _owned_driver_or_404(owner_id, driver_id)

    if "file" not in request.files:
        raise ValidationError({"file": "No file uploaded"})

    relative_path = save_upload(
        request.files["file"],
        subfolder=f"drivers/{driver.id}",
        allowed_extensions=current_app.config["ALLOWED_IMAGE_EXTENSIONS"],
    )
    driver.photo = relative_path
    db.session.commit()
    return jsonify({"success": True, "driver": driver.to_dict()})


@drivers_bp.route("/<int:driver_id>/assign", methods=["POST"])
@jwt_required()
def assign_driver(driver_id):
    owner_id = get_jwt_identity()
    driver = _owned_driver_or_404(owner_id, driver_id)
    data = request.get_json(force=True)
    require_fields(data, ["car_id"])

    car = Car.query.filter_by(id=data["car_id"], owner_id=owner_id).first()
    if not car:
        raise ValidationError({"car_id": "Car not found"})

    # deactivate any existing active assignment for this driver
    DriverAssignment.query.filter_by(driver_id=driver.id, is_active=True).update({"is_active": False})

    assignment = DriverAssignment(driver_id=driver.id, car_id=car.id)
    driver.status = "on_trip"
    db.session.add(assignment)
    db.session.commit()

    return jsonify({"success": True, "assignment": assignment.to_dict()}), 201


@drivers_bp.route("/<int:driver_id>/unassign", methods=["POST"])
@jwt_required()
def unassign_driver(driver_id):
    owner_id = get_jwt_identity()
    driver = _owned_driver_or_404(owner_id, driver_id)

    from datetime import datetime

    assignment = DriverAssignment.query.filter_by(driver_id=driver.id, is_active=True).first()
    if assignment:
        assignment.is_active = False
        assignment.unassigned_at = datetime.utcnow()
    driver.status = "active"
    db.session.commit()

    return jsonify({"success": True, "message": "Driver unassigned"})
