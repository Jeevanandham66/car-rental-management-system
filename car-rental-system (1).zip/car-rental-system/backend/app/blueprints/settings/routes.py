from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from app.extensions import db
from app.models.owner import OwnerSettings

settings_bp = Blueprint("settings", __name__, url_prefix="/api/settings")


@settings_bp.route("", methods=["GET"])
@jwt_required()
def get_settings():
    owner_id = get_jwt_identity()
    settings = OwnerSettings.query.filter_by(owner_id=owner_id).first()
    if not settings:
        settings = OwnerSettings(owner_id=owner_id)
        db.session.add(settings)
        db.session.commit()
    return jsonify({"success": True, "settings": settings.to_dict()})


@settings_bp.route("", methods=["PUT"])
@jwt_required()
def update_settings():
    owner_id = get_jwt_identity()
    settings = OwnerSettings.query.filter_by(owner_id=owner_id).first()
    if not settings:
        settings = OwnerSettings(owner_id=owner_id)
        db.session.add(settings)

    data = request.get_json(force=True)
    if "gst_percentage" in data:
        settings.gst_percentage = data["gst_percentage"]
    if "notification_days" in data:
        settings.notification_days = data["notification_days"]
    if "default_daily_rent" in data:
        settings.default_daily_rent = data["default_daily_rent"]

    db.session.commit()
    return jsonify({"success": True, "settings": settings.to_dict()})
