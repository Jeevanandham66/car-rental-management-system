import os
from flask import Flask, jsonify, send_from_directory

from app.config import config_by_name
from app.extensions import db, migrate, jwt, cors, bcrypt


def create_app(env=None):
    env = env or os.getenv("FLASK_ENV", "development")
    app = Flask(__name__)
    app.config.from_object(config_by_name[env])

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    # Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    bcrypt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}}, supports_credentials=True)

    # Models must be imported so Flask-Migrate can detect them
    from app import models  # noqa: F401

    # Blueprints
    from app.blueprints.auth.routes import auth_bp
    from app.blueprints.dashboard.routes import dashboard_bp
    from app.blueprints.cars.routes import cars_bp
    from app.blueprints.documents.routes import documents_bp
    from app.blueprints.drivers.routes import drivers_bp
    from app.blueprints.service.routes import service_bp
    from app.blueprints.bookings.routes import bookings_bp
    from app.blueprints.search.routes import search_bp
    from app.blueprints.reports.routes import reports_bp
    from app.blueprints.notifications.routes import notifications_bp
    from app.blueprints.settings.routes import settings_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(cars_bp)
    app.register_blueprint(documents_bp)
    app.register_blueprint(drivers_bp)
    app.register_blueprint(service_bp)
    app.register_blueprint(bookings_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(settings_bp)

    @app.route("/api/uploads/<path:filename>")
    def serve_upload(filename):
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    @app.route("/api/health", methods=["GET"])
    def health_check():
        return jsonify({"success": True, "message": "Car Rental Management API is running"})

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"success": False, "error": "Resource not found"}), 404

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()
        return jsonify({"success": False, "error": "Internal server error"}), 500

    return app
