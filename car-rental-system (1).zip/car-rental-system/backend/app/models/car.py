from datetime import datetime
from app.extensions import db


class Car(db.Model):
    __tablename__ = "cars"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("owners.id"), nullable=False)

    # Basic Details
    vehicle_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    brand = db.Column(db.String(80), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    variant = db.Column(db.String(80))
    manufacturing_year = db.Column(db.Integer, nullable=False)
    fuel_type = db.Column(db.String(20), nullable=False)  # Petrol/Diesel/CNG/Electric/Hybrid
    transmission = db.Column(db.String(20), nullable=False)  # Manual/Automatic
    color = db.Column(db.String(40))
    engine_number = db.Column(db.String(80), unique=True)
    chassis_number = db.Column(db.String(80), unique=True)
    odometer_reading = db.Column(db.Integer, default=0)
    mileage = db.Column(db.Numeric(6, 2))
    seating_capacity = db.Column(db.Integer, default=4)

    # Rental Details
    daily_rent = db.Column(db.Numeric(10, 2), nullable=False)
    weekly_rent = db.Column(db.Numeric(10, 2))
    monthly_rent = db.Column(db.Numeric(10, 2))
    security_deposit = db.Column(db.Numeric(10, 2), default=0)
    extra_km_charge = db.Column(db.Numeric(10, 2), default=0)
    night_charge = db.Column(db.Numeric(10, 2), default=0)
    driver_charge_per_day = db.Column(db.Numeric(10, 2), default=0)

    # Driver Option: with_driver / without_driver / both
    driver_option = db.Column(db.String(20), default="both")

    # Availability: available / booked / service / inactive
    availability_status = db.Column(db.String(20), default="available", index=True)

    # Condition: excellent / very_good / good / needs_service
    condition = db.Column(db.String(20), default="good")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    checklist = db.relationship("CarInspectionChecklist", backref="car", uselist=False, cascade="all, delete-orphan")
    images = db.relationship("CarImage", backref="car", lazy=True, cascade="all, delete-orphan")
    documents = db.relationship("VehicleDocument", backref="car", lazy=True, cascade="all, delete-orphan")
    service_records = db.relationship("ServiceRecord", backref="car", lazy=True, cascade="all, delete-orphan")
    bookings = db.relationship("Booking", backref="car", lazy=True, cascade="all, delete-orphan")
    driver_assignments = db.relationship("DriverAssignment", backref="car", lazy=True, cascade="all, delete-orphan")

    def to_dict(self, include_relations=False):
        data = {
            "id": self.id,
            "vehicle_number": self.vehicle_number,
            "brand": self.brand,
            "model": self.model,
            "variant": self.variant,
            "manufacturing_year": self.manufacturing_year,
            "fuel_type": self.fuel_type,
            "transmission": self.transmission,
            "color": self.color,
            "engine_number": self.engine_number,
            "chassis_number": self.chassis_number,
            "odometer_reading": self.odometer_reading,
            "mileage": float(self.mileage) if self.mileage else None,
            "seating_capacity": self.seating_capacity,
            "daily_rent": float(self.daily_rent) if self.daily_rent else None,
            "weekly_rent": float(self.weekly_rent) if self.weekly_rent else None,
            "monthly_rent": float(self.monthly_rent) if self.monthly_rent else None,
            "security_deposit": float(self.security_deposit) if self.security_deposit else None,
            "extra_km_charge": float(self.extra_km_charge) if self.extra_km_charge else None,
            "night_charge": float(self.night_charge) if self.night_charge else None,
            "driver_charge_per_day": float(self.driver_charge_per_day) if self.driver_charge_per_day else None,
            "driver_option": self.driver_option,
            "availability_status": self.availability_status,
            "condition": self.condition,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        if include_relations:
            data["checklist"] = self.checklist.to_dict() if self.checklist else None
            data["images"] = [img.to_dict() for img in self.images]
            data["documents"] = [doc.to_dict() for doc in self.documents]
        return data


class CarInspectionChecklist(db.Model):
    __tablename__ = "car_inspection_checklist"

    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey("cars.id"), unique=True, nullable=False)

    engine_ok = db.Column(db.Boolean, default=False)
    brakes_ok = db.Column(db.Boolean, default=False)
    tyres_ok = db.Column(db.Boolean, default=False)
    battery_ok = db.Column(db.Boolean, default=False)
    lights_ok = db.Column(db.Boolean, default=False)
    horn_ok = db.Column(db.Boolean, default=False)
    ac_ok = db.Column(db.Boolean, default=False)
    seat_covers_ok = db.Column(db.Boolean, default=False)
    music_system_ok = db.Column(db.Boolean, default=False)
    gps_ok = db.Column(db.Boolean, default=False)

    checked_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "engine_ok": self.engine_ok,
            "brakes_ok": self.brakes_ok,
            "tyres_ok": self.tyres_ok,
            "battery_ok": self.battery_ok,
            "lights_ok": self.lights_ok,
            "horn_ok": self.horn_ok,
            "ac_ok": self.ac_ok,
            "seat_covers_ok": self.seat_covers_ok,
            "music_system_ok": self.music_system_ok,
            "gps_ok": self.gps_ok,
        }


class CarImage(db.Model):
    __tablename__ = "car_images"

    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey("cars.id"), nullable=False)
    # front / rear / left / right / interior / dashboard / engine / tyres
    image_type = db.Column(db.String(20), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "image_type": self.image_type,
            "file_path": self.file_path,
            "uploaded_at": self.uploaded_at.isoformat() if self.uploaded_at else None,
        }
