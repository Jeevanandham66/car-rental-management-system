from datetime import datetime
from app.extensions import db


class ServiceRecord(db.Model):
    __tablename__ = "service_records"

    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey("cars.id"), nullable=False)

    service_date = db.Column(db.Date, nullable=False)
    service_center = db.Column(db.String(150))
    service_type = db.Column(db.String(80))  # routine / repair / accident / other
    cost = db.Column(db.Numeric(10, 2), default=0)
    odometer_reading = db.Column(db.Integer)
    next_service_due_date = db.Column(db.Date, nullable=True)
    next_service_due_km = db.Column(db.Integer, nullable=True)
    bill_upload = db.Column(db.String(255))
    notes = db.Column(db.Text)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "car_id": self.car_id,
            "service_date": self.service_date.isoformat() if self.service_date else None,
            "service_center": self.service_center,
            "service_type": self.service_type,
            "cost": float(self.cost) if self.cost else None,
            "odometer_reading": self.odometer_reading,
            "next_service_due_date": self.next_service_due_date.isoformat() if self.next_service_due_date else None,
            "next_service_due_km": self.next_service_due_km,
            "bill_upload": self.bill_upload,
            "notes": self.notes,
        }
