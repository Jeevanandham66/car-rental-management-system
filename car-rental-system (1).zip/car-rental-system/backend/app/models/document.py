from datetime import datetime
from app.extensions import db

DOCUMENT_TYPES = [
    "rc_book",
    "insurance",
    "fitness_certificate",
    "pollution_certificate",
    "road_tax",
    "permit",
    "driving_permit",
    "invoice",
    "service_records",
]


class VehicleDocument(db.Model):
    __tablename__ = "vehicle_documents"

    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey("cars.id"), nullable=False)

    document_type = db.Column(db.String(40), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)

    issue_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date, index=True)
    reminder_days_before = db.Column(db.Integer, default=15)

    # valid / expiring_soon / expired
    status = db.Column(db.String(20), default="valid")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "car_id": self.car_id,
            "document_type": self.document_type,
            "file_path": self.file_path,
            "issue_date": self.issue_date.isoformat() if self.issue_date else None,
            "expiry_date": self.expiry_date.isoformat() if self.expiry_date else None,
            "reminder_days_before": self.reminder_days_before,
            "status": self.status,
        }
