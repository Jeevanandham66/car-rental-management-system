from datetime import datetime
from app.extensions import db


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("owners.id"), nullable=False)

    # insurance_expiry / fc_expiry / license_expiry / permit_expiry / service_due / document_expiry
    notification_type = db.Column(db.String(40), nullable=False)
    reference_table = db.Column(db.String(40))
    reference_id = db.Column(db.Integer)

    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text)
    due_date = db.Column(db.Date, index=True)

    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "notification_type": self.notification_type,
            "reference_table": self.reference_table,
            "reference_id": self.reference_id,
            "title": self.title,
            "message": self.message,
            "due_date": self.due_date.isoformat() if self.due_date else None,
            "is_read": self.is_read,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
