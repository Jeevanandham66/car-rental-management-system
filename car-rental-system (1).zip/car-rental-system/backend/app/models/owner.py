import uuid
from datetime import datetime
from app.extensions import db


class Owner(db.Model):
    __tablename__ = "owners"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    company_name = db.Column(db.String(150))
    profile_photo = db.Column(db.String(255))

    reset_token = db.Column(db.String(255), nullable=True)
    reset_token_expiry = db.Column(db.DateTime, nullable=True)

    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    cars = db.relationship("Car", backref="owner", lazy=True, cascade="all, delete-orphan")
    drivers = db.relationship("Driver", backref="owner", lazy=True, cascade="all, delete-orphan")
    settings = db.relationship("OwnerSettings", backref="owner", uselist=False, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "full_name": self.full_name,
            "email": self.email,
            "phone": self.phone,
            "company_name": self.company_name,
            "profile_photo": self.profile_photo,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class OwnerSettings(db.Model):
    __tablename__ = "owner_settings"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("owners.id"), unique=True, nullable=False)
    gst_percentage = db.Column(db.Numeric(5, 2), default=18.00)
    notification_days = db.Column(db.Integer, default=15)
    default_daily_rent = db.Column(db.Numeric(10, 2), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "gst_percentage": float(self.gst_percentage) if self.gst_percentage is not None else None,
            "notification_days": self.notification_days,
            "default_daily_rent": float(self.default_daily_rent) if self.default_daily_rent else None,
        }
