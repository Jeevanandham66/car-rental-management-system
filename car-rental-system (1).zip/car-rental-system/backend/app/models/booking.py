from datetime import datetime
from app.extensions import db


class Booking(db.Model):
    __tablename__ = "bookings"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("owners.id"), nullable=False)
    car_id = db.Column(db.Integer, db.ForeignKey("cars.id"), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=True)

    booking_number = db.Column(db.String(30), unique=True, nullable=False, index=True)

    customer_name = db.Column(db.String(120), nullable=False)
    customer_phone = db.Column(db.String(20), nullable=False)
    customer_email = db.Column(db.String(150))
    driving_license_upload = db.Column(db.String(255))

    pickup_date = db.Column(db.DateTime, nullable=False)
    return_date = db.Column(db.DateTime, nullable=False)
    pickup_location = db.Column(db.String(200))
    drop_location = db.Column(db.String(200))

    # with_driver / without_driver
    rental_type = db.Column(db.String(20), nullable=False)

    number_of_days = db.Column(db.Integer, nullable=False)
    rent_amount = db.Column(db.Numeric(10, 2), nullable=False)
    driver_charge = db.Column(db.Numeric(10, 2), default=0)
    extra_km_used = db.Column(db.Integer, default=0)
    extra_km_charge_total = db.Column(db.Numeric(10, 2), default=0)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    gst_percentage = db.Column(db.Numeric(5, 2), default=18)
    gst_amount = db.Column(db.Numeric(10, 2), default=0)
    discount = db.Column(db.Numeric(10, 2), default=0)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    security_deposit_collected = db.Column(db.Numeric(10, 2), default=0)

    # confirmed / ongoing / completed / cancelled
    status = db.Column(db.String(20), default="confirmed", index=True)

    invoice_number = db.Column(db.String(30))
    invoice_pdf_path = db.Column(db.String(255))

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "booking_number": self.booking_number,
            "car_id": self.car_id,
            "driver_id": self.driver_id,
            "customer_name": self.customer_name,
            "customer_phone": self.customer_phone,
            "customer_email": self.customer_email,
            "driving_license_upload": self.driving_license_upload,
            "pickup_date": self.pickup_date.isoformat() if self.pickup_date else None,
            "return_date": self.return_date.isoformat() if self.return_date else None,
            "pickup_location": self.pickup_location,
            "drop_location": self.drop_location,
            "rental_type": self.rental_type,
            "number_of_days": self.number_of_days,
            "rent_amount": float(self.rent_amount) if self.rent_amount else None,
            "driver_charge": float(self.driver_charge) if self.driver_charge else None,
            "extra_km_used": self.extra_km_used,
            "extra_km_charge_total": float(self.extra_km_charge_total) if self.extra_km_charge_total else None,
            "subtotal": float(self.subtotal) if self.subtotal else None,
            "gst_percentage": float(self.gst_percentage) if self.gst_percentage else None,
            "gst_amount": float(self.gst_amount) if self.gst_amount else None,
            "discount": float(self.discount) if self.discount else None,
            "total_amount": float(self.total_amount) if self.total_amount else None,
            "security_deposit_collected": float(self.security_deposit_collected) if self.security_deposit_collected else None,
            "status": self.status,
            "invoice_number": self.invoice_number,
            "invoice_pdf_path": self.invoice_pdf_path,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
