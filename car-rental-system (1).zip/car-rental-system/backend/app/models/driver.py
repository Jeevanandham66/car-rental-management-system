from datetime import datetime
from app.extensions import db


class Driver(db.Model):
    __tablename__ = "drivers"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("owners.id"), nullable=False)

    name = db.Column(db.String(120), nullable=False)
    photo = db.Column(db.String(255))
    phone = db.Column(db.String(20), nullable=False)
    license_number = db.Column(db.String(60), unique=True, nullable=False)
    license_expiry = db.Column(db.Date, nullable=False, index=True)
    address = db.Column(db.Text)
    aadhar_number = db.Column(db.String(20))
    experience_years = db.Column(db.Numeric(4, 1))
    salary = db.Column(db.Numeric(10, 2))

    # active / inactive / on_trip
    status = db.Column(db.String(20), default="active")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    assignments = db.relationship("DriverAssignment", backref="driver", lazy=True, cascade="all, delete-orphan")
    bookings = db.relationship("Booking", backref="driver", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "photo": self.photo,
            "phone": self.phone,
            "license_number": self.license_number,
            "license_expiry": self.license_expiry.isoformat() if self.license_expiry else None,
            "address": self.address,
            "aadhar_number": self.aadhar_number,
            "experience_years": float(self.experience_years) if self.experience_years else None,
            "salary": float(self.salary) if self.salary else None,
            "status": self.status,
        }


class DriverAssignment(db.Model):
    __tablename__ = "driver_assignments"

    id = db.Column(db.Integer, primary_key=True)
    driver_id = db.Column(db.Integer, db.ForeignKey("drivers.id"), nullable=False)
    car_id = db.Column(db.Integer, db.ForeignKey("cars.id"), nullable=False)
    assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
    unassigned_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            "id": self.id,
            "driver_id": self.driver_id,
            "car_id": self.car_id,
            "assigned_at": self.assigned_at.isoformat() if self.assigned_at else None,
            "is_active": self.is_active,
        }
