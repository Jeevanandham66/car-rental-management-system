# Car Rental Management System

A full-stack Car Rental Management System for rental car owners: React + Tailwind frontend, Flask REST API backend, PostgreSQL database, JWT auth, local file uploads.

## Project Structure

```
car-rental-system/
├── backend/            Flask REST API (Blueprints, SQLAlchemy, JWT)
│   ├── app/
│   │   ├── blueprints/ auth, dashboard, cars, drivers, bookings,
│   │   │               documents, service, search, reports,
│   │   │               notifications, settings
│   │   ├── models/     SQLAlchemy models
│   │   ├── utils/      validators, file upload, QR, PDF, Excel, invoice calc
│   │   ├── static/uploads/  uploaded images/documents (created at runtime)
│   │   ├── config.py
│   │   └── extensions.py
│   ├── run.py
│   ├── requirements.txt
│   └── .env.example
├── database/
│   └── schema.sql      Full normalized PostgreSQL schema (matches the models)
├── frontend/            React + Tailwind CSS (Vite)
│   └── src/
│       ├── api/         axios client + endpoint helpers
│       ├── context/      Auth + Theme (dark mode) context
│       ├── layouts/      Sidebar dashboard layout
│       ├── pages/         Login, Register, Dashboard, Cars, Drivers,
│       │                  Bookings, Service, Documents, Reports, Settings
│       └── components/    DataTable, Modal, Badge, StatCard, ProtectedRoute
└── docker-compose.yml   Postgres + backend for local dev
```

## Backend Setup

```bash
cd backend
python3 -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env           # then edit DATABASE_URL, SECRET_KEY, JWT_SECRET_KEY

# Create the database and load the schema
createdb car_rental_db
psql car_rental_db < ../database/schema.sql

# (Optional, once you're iterating on models) initialize Flask-Migrate:
flask db init
flask db migrate -m "initial"
flask db upgrade

python run.py                  # runs on http://localhost:5000
```

The schema.sql file is the source of truth for the DB structure and can be
run directly against a fresh PostgreSQL database — you don't need
Flask-Migrate to get started, only if you plan to evolve the schema over time.

## Frontend Setup

```bash
cd frontend
npm install
npm run dev                    # runs on http://localhost:5173, proxies /api to :5000
```

## Docker (Postgres + backend only)

```bash
docker compose up --build
# then, in a separate terminal:
cd frontend && npm install && npm run dev
```

## Key Features Implemented

- JWT auth: register, login, refresh, forgot/reset password, profile
- Dashboard: fleet counts, monthly revenue, today's bookings, pending
  documents, upcoming insurance/FC expiry
- Car registration: full basic + rental details, driver option,
  availability, condition, 10-point inspection checklist, 8 image slots
- Vehicle documents: RC book, insurance, FC, PUC, road tax, permits,
  invoice, service records — each with issue/expiry date, reminder window,
  and computed status (valid / expiring soon / expired)
- Driver management + assignment to vehicles
- Service history with next-service-due tracking and bill uploads
- Bookings: automatic day/rent/driver-charge/GST/discount/total
  calculation with weekly/monthly rent slabs, and PDF invoice generation
- Search across vehicle number, brand, driver, availability, and
  insurance/FC expiry windows
- Reports: monthly/yearly revenue, car utilization, most-booked vehicle,
  service cost — each exportable to PDF or Excel
- Live notifications for insurance/FC/license/permit expiry and service due
- Admin settings: GST %, notification window, default daily rent, profile
- QR code generation and PDF spec sheet download per vehicle
- Dark mode, responsive sidebar layout, pagination + search on all tables

## Notes & Next Steps

- Email delivery for password resets is stubbed (the reset token is
  generated and stored, but no email is actually sent) — wire up
  Flask-Mail or a transactional email provider for production.
- File uploads are stored on local disk under `app/static/uploads/`;
  swap `app/utils/file_upload.py` for S3/GCS if you need it to scale
  beyond a single server.
- Add role-based access if you ever support multiple staff logins per
  owner account — currently each owner is a single login scoped to their
  own data.
